/*
  # Dados de Exemplo para o Sistema de Hospedagem

  1. Planos de Hospedagem
  2. Planos VPS
  3. Planos E-commerce
  4. Configurações do Sistema
*/

-- Inserir planos de hospedagem
INSERT INTO hosting_plans (name, description, price, billing_cycle, features) VALUES
('Starter', 'Perfeito para sites pessoais e pequenos projetos', 19.90, 'monthly', '{
  "storage_gb": 5,
  "bandwidth_gb": 100,
  "domains": 1,
  "emails": 5,
  "databases": 1,
  "ssl": true,
  "backup": "weekly"
}'),
('Professional', 'Ideal para pequenas empresas e lojas online', 39.90, 'monthly', '{
  "storage_gb": 25,
  "bandwidth_gb": 500,
  "domains": -1,
  "emails": -1,
  "databases": 10,
  "ssl": true,
  "backup": "daily",
  "woocommerce": true,
  "staging": true
}'),
('Business', 'Para empresas que precisam de máxima performance', 79.90, 'monthly', '{
  "storage_gb": 100,
  "bandwidth_gb": 1000,
  "domains": -1,
  "emails": -1,
  "databases": -1,
  "ssl": true,
  "backup": "daily",
  "woocommerce": true,
  "staging": true,
  "cdn": true,
  "priority_support": true
}');

-- Inserir planos VPS
INSERT INTO vps_plans (name, description, price, billing_cycle, specs, features) VALUES
('VPS Basic', 'Servidor virtual básico para projetos pequenos', 89.90, 'monthly', '{
  "cpu_cores": 2,
  "ram_gb": 4,
  "storage_gb": 80,
  "bandwidth_gb": 5000
}', '{
  "backup": true,
  "monitoring": true,
  "support_level": "standard",
  "os_options": ["Ubuntu", "CentOS", "Debian"],
  "root_access": true
}'),
('VPS Pro', 'Servidor virtual profissional para aplicações médias', 169.90, 'monthly', '{
  "cpu_cores": 4,
  "ram_gb": 8,
  "storage_gb": 160,
  "bandwidth_gb": 10000
}', '{
  "backup": true,
  "monitoring": true,
  "support_level": "priority",
  "os_options": ["Ubuntu", "CentOS", "Debian", "Windows"],
  "root_access": true,
  "snapshots": true
}'),
('VPS Advanced', 'Servidor virtual avançado para aplicações críticas', 299.90, 'monthly', '{
  "cpu_cores": 6,
  "ram_gb": 16,
  "storage_gb": 320,
  "bandwidth_gb": 20000
}', '{
  "backup": true,
  "monitoring": true,
  "support_level": "premium",
  "os_options": ["Ubuntu", "CentOS", "Debian", "Windows"],
  "root_access": true,
  "snapshots": true,
  "load_balancer": true,
  "dedicated_ip": true
}');

-- Inserir planos de e-commerce
INSERT INTO ecommerce_plans (name, description, price, billing_cycle, features) VALUES
('E-commerce Starter', 'Loja virtual básica para começar a vender', 49.90, 'monthly', '{
  "products_limit": 100,
  "storage_gb": 10,
  "bandwidth_gb": 200,
  "payment_gateways": ["PagSeguro", "Mercado Pago"],
  "themes": 5,
  "ssl": true,
  "mobile_responsive": true
}'),
('E-commerce Pro', 'Loja virtual profissional com recursos avançados', 99.90, 'monthly', '{
  "products_limit": 1000,
  "storage_gb": 50,
  "bandwidth_gb": 1000,
  "payment_gateways": ["PagSeguro", "Mercado Pago", "PayPal", "Stripe"],
  "themes": 20,
  "ssl": true,
  "mobile_responsive": true,
  "abandoned_cart": true,
  "analytics": true,
  "seo_tools": true
}'),
('E-commerce Enterprise', 'Solução completa para grandes operações', 199.90, 'monthly', '{
  "products_limit": -1,
  "storage_gb": 200,
  "bandwidth_gb": 5000,
  "payment_gateways": ["PagSeguro", "Mercado Pago", "PayPal", "Stripe", "Custom"],
  "themes": -1,
  "ssl": true,
  "mobile_responsive": true,
  "abandoned_cart": true,
  "analytics": true,
  "seo_tools": true,
  "multi_store": true,
  "api_access": true,
  "priority_support": true
}');

-- Inserir configurações do sistema
INSERT INTO system_settings (key, value, description) VALUES
('company_name', '"HostPro"', 'Nome da empresa'),
('company_email', '"contato@hostpro.com.br"', 'Email principal da empresa'),
('company_phone', '"(11) 4000-0000"', 'Telefone da empresa'),
('company_address', '{
  "street": "Rua das Empresas, 123",
  "city": "São Paulo",
  "state": "SP",
  "zip": "01234-567",
  "country": "Brasil"
}', 'Endereço da empresa'),
('tax_rate', '0.18', 'Taxa de imposto padrão'),
('currency', '"BRL"', 'Moeda padrão'),
('invoice_prefix', '"INV"', 'Prefixo das faturas'),
('trial_period_days', '30', 'Período de teste em dias'),
('backup_retention_days', '30', 'Dias de retenção de backup'),
('support_email', '"suporte@hostpro.com.br"', 'Email do suporte'),
('notification_settings', '{
  "invoice_due": true,
  "payment_received": true,
  "service_suspended": true,
  "backup_failed": true,
  "ticket_created": true
}', 'Configurações de notificação');