import { supabase } from '../lib/supabase';
import type { Customer } from '../lib/supabase';

export class CustomerService {
  // Criar novo cliente
  static async createCustomer(customerData: Omit<Customer, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('customers')
      .insert([customerData])
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Buscar cliente por ID
  static async getCustomerById(id: string) {
    const { data, error } = await supabase
      .from('customers')
      .select('*')
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  }

  // Buscar cliente por user_id
  static async getCustomerByUserId(userId: string) {
    const { data, error } = await supabase
      .from('customers')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (error) throw error;
    return data;
  }

  // Atualizar cliente
  static async updateCustomer(id: string, updates: Partial<Customer>) {
    const { data, error } = await supabase
      .from('customers')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Listar todos os clientes (admin)
  static async getAllCustomers(page = 1, limit = 10) {
    const offset = (page - 1) * limit;
    
    const { data, error, count } = await supabase
      .from('customers')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;
    return { customers: data, total: count };
  }

  // Buscar clientes por filtros
  static async searchCustomers(filters: {
    email?: string;
    company_name?: string;
    is_active?: boolean;
  }) {
    let query = supabase.from('customers').select('*');

    if (filters.email) {
      query = query.ilike('email', `%${filters.email}%`);
    }
    if (filters.company_name) {
      query = query.ilike('company_name', `%${filters.company_name}%`);
    }
    if (filters.is_active !== undefined) {
      query = query.eq('is_active', filters.is_active);
    }

    const { data, error } = await query.order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  }

  // Desativar cliente
  static async deactivateCustomer(id: string) {
    const { data, error } = await supabase
      .from('customers')
      .update({ is_active: false })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Reativar cliente
  static async activateCustomer(id: string) {
    const { data, error } = await supabase
      .from('customers')
      .update({ is_active: true })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }
}