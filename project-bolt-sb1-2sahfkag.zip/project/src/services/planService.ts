import { supabase } from '../lib/supabase';
import type { HostingPlan, VPSPlan, EcommercePlan } from '../lib/supabase';

export class PlanService {
  // Hosting Plans
  static async getHostingPlans() {
    const { data, error } = await supabase
      .from('hosting_plans')
      .select('*')
      .eq('is_active', true)
      .order('price', { ascending: true });

    if (error) throw error;
    return data;
  }

  static async getHostingPlanById(id: string) {
    const { data, error } = await supabase
      .from('hosting_plans')
      .select('*')
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  }

  // VPS Plans
  static async getVPSPlans() {
    const { data, error } = await supabase
      .from('vps_plans')
      .select('*')
      .eq('is_active', true)
      .order('price', { ascending: true });

    if (error) throw error;
    return data;
  }

  static async getVPSPlanById(id: string) {
    const { data, error } = await supabase
      .from('vps_plans')
      .select('*')
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  }

  // E-commerce Plans
  static async getEcommercePlans() {
    const { data, error } = await supabase
      .from('ecommerce_plans')
      .select('*')
      .eq('is_active', true)
      .order('price', { ascending: true });

    if (error) throw error;
    return data;
  }

  static async getEcommercePlanById(id: string) {
    const { data, error } = await supabase
      .from('ecommerce_plans')
      .select('*')
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  }

  // Admin functions
  static async createHostingPlan(planData: Omit<HostingPlan, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('hosting_plans')
      .insert([planData])
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  static async updateHostingPlan(id: string, updates: Partial<HostingPlan>) {
    const { data, error } = await supabase
      .from('hosting_plans')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  static async createVPSPlan(planData: Omit<VPSPlan, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('vps_plans')
      .insert([planData])
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  static async updateVPSPlan(id: string, updates: Partial<VPSPlan>) {
    const { data, error } = await supabase
      .from('vps_plans')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  static async createEcommercePlan(planData: Omit<EcommercePlan, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('ecommerce_plans')
      .insert([planData])
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  static async updateEcommercePlan(id: string, updates: Partial<EcommercePlan>) {
    const { data, error } = await supabase
      .from('ecommerce_plans')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }
}