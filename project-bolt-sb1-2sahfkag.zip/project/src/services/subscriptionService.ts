import { supabase } from '../lib/supabase';
import type { Subscription } from '../lib/supabase';

export class SubscriptionService {
  // Criar nova assinatura
  static async createSubscription(subscriptionData: Omit<Subscription, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('subscriptions')
      .insert([subscriptionData])
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Buscar assinaturas do cliente
  static async getCustomerSubscriptions(customerId: string) {
    const { data, error } = await supabase
      .from('subscriptions')
      .select(`
        *,
        hosting_plans:hosting_plans(name, features),
        vps_plans:vps_plans(name, specs),
        ecommerce_plans:ecommerce_plans(name, features)
      `)
      .eq('customer_id', customerId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  }

  // Buscar assinatura por ID
  static async getSubscriptionById(id: string) {
    const { data, error } = await supabase
      .from('subscriptions')
      .select(`
        *,
        customers(contact_name, email),
        hosting_plans(name, features),
        vps_plans(name, specs),
        ecommerce_plans(name, features)
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  }

  // Atualizar status da assinatura
  static async updateSubscriptionStatus(id: string, status: Subscription['status']) {
    const { data, error } = await supabase
      .from('subscriptions')
      .update({ status })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Renovar assinatura
  static async renewSubscription(id: string, expiresAt: string) {
    const { data, error } = await supabase
      .from('subscriptions')
      .update({ 
        expires_at: expiresAt,
        status: 'active'
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Cancelar assinatura
  static async cancelSubscription(id: string) {
    const { data, error } = await supabase
      .from('subscriptions')
      .update({ 
        status: 'cancelled',
        auto_renew: false
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Suspender assinatura
  static async suspendSubscription(id: string) {
    const { data, error } = await supabase
      .from('subscriptions')
      .update({ status: 'suspended' })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Reativar assinatura
  static async reactivateSubscription(id: string) {
    const { data, error } = await supabase
      .from('subscriptions')
      .update({ status: 'active' })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Buscar assinaturas que expiram em breve
  static async getExpiringSubscriptions(days = 7) {
    const expirationDate = new Date();
    expirationDate.setDate(expirationDate.getDate() + days);

    const { data, error } = await supabase
      .from('subscriptions')
      .select(`
        *,
        customers(contact_name, email)
      `)
      .eq('status', 'active')
      .eq('auto_renew', true)
      .lte('expires_at', expirationDate.toISOString())
      .order('expires_at', { ascending: true });

    if (error) throw error;
    return data;
  }

  // Buscar todas as assinaturas (admin)
  static async getAllSubscriptions(page = 1, limit = 10, filters?: {
    status?: string;
    service_type?: string;
  }) {
    const offset = (page - 1) * limit;
    
    let query = supabase
      .from('subscriptions')
      .select(`
        *,
        customers(contact_name, email, company_name)
      `, { count: 'exact' });

    if (filters?.status) {
      query = query.eq('status', filters.status);
    }
    if (filters?.service_type) {
      query = query.eq('service_type', filters.service_type);
    }

    const { data, error, count } = await query
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;
    return { subscriptions: data, total: count };
  }

  // Estatísticas de assinaturas
  static async getSubscriptionStats() {
    const { data, error } = await supabase
      .from('subscriptions')
      .select('status, service_type');

    if (error) throw error;

    const stats = {
      total: data.length,
      active: data.filter(s => s.status === 'active').length,
      suspended: data.filter(s => s.status === 'suspended').length,
      cancelled: data.filter(s => s.status === 'cancelled').length,
      pending: data.filter(s => s.status === 'pending').length,
      by_service: {
        hosting: data.filter(s => s.service_type === 'hosting').length,
        vps: data.filter(s => s.service_type === 'vps').length,
        ecommerce: data.filter(s => s.service_type === 'ecommerce').length,
        domain: data.filter(s => s.service_type === 'domain').length,
      }
    };

    return stats;
  }
}