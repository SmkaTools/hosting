import React from 'react';
import { Server, ShoppingCart, Cloud, Zap, Shield, Headphones } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Server,
      title: 'Hospedagem Web',
      description: 'Hospedagem compartilhada e dedicada com tecnologia de ponta para garantir máxima performance.',
      features: ['cPanel incluído', 'PHP 8.2', 'MySQL ilimitado', 'Email profissional'],
      color: 'blue'
    },
    {
      icon: ShoppingCart,
      title: 'Loja Virtual',
      description: 'Plataforma completa de e-commerce com todas as ferramentas para vender online.',
      features: ['WooCommerce', 'Pagamentos integrados', 'Gestão de estoque', 'Relatórios avançados'],
      color: 'green'
    },
    {
      icon: Cloud,
      title: 'Servidores VPS',
      description: 'Servidores virtuais privados com recursos dedicados e controle total.',
      features: ['SSD NVMe', 'Root access', 'Backup automático', 'Múltiplas localizações'],
      color: 'purple'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: {
        bg: 'bg-blue-50',
        icon: 'text-blue-600',
        button: 'bg-blue-600 hover:bg-blue-700'
      },
      green: {
        bg: 'bg-green-50',
        icon: 'text-green-600',
        button: 'bg-green-600 hover:bg-green-700'
      },
      purple: {
        bg: 'bg-purple-50',
        icon: 'text-purple-600',
        button: 'bg-purple-600 hover:bg-purple-700'
      }
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Nossos Serviços
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Oferecemos uma gama completa de soluções de hospedagem para atender 
            todas as necessidades do seu negócio digital.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => {
            const colors = getColorClasses(service.color);
            const Icon = service.icon;
            
            return (
              <div key={index} className="group">
                <div className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 p-8 h-full">
                  <div className={`${colors.bg} w-16 h-16 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                    <Icon className={`h-8 w-8 ${colors.icon}`} />
                  </div>
                  
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">
                    {service.title}
                  </h3>
                  
                  <p className="text-gray-600 mb-6 leading-relaxed">
                    {service.description}
                  </p>

                  <ul className="space-y-3 mb-8">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center space-x-3">
                        <div className={`w-2 h-2 ${colors.button.split(' ')[0]} rounded-full`}></div>
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <button className={`w-full ${colors.button} text-white py-3 rounded-lg transition-colors font-semibold`}>
                    Ver Planos
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="grid md:grid-cols-3 gap-8 text-center">
          {[
            { icon: Zap, title: 'Performance', description: 'Velocidade otimizada' },
            { icon: Shield, title: 'Segurança', description: 'Proteção avançada' },
            { icon: Headphones, title: 'Suporte 24/7', description: 'Atendimento especializado' }
          ].map((item, index) => {
            const Icon = item.icon;
            return (
              <div key={index} className="group cursor-pointer">
                <div className="bg-gradient-to-br from-gray-50 to-gray-100 p-6 rounded-xl group-hover:from-blue-50 group-hover:to-blue-100 transition-all">
                  <Icon className="h-8 w-8 text-blue-600 mx-auto mb-4 group-hover:scale-110 transition-transform" />
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">{item.title}</h4>
                  <p className="text-gray-600">{item.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Services;