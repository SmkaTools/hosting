import React from 'react';
import { Check, Star } from 'lucide-react';

const Pricing = () => {
  const plans = [
    {
      name: 'Starter',
      price: 'R$ 19,90',
      period: '/mês',
      description: 'Perfeito para sites pessoais e pequenos projetos',
      features: [
        '5 GB de armazenamento SSD',
        '1 site',
        'Largura de banda ilimitada',
        'SSL grátis',
        'Email profissional',
        'Suporte por ticket'
      ],
      popular: false,
      color: 'gray'
    },
    {
      name: 'Professional',
      price: 'R$ 39,90',
      period: '/mês',
      description: 'Ideal para pequenas empresas e lojas online',
      features: [
        '25 GB de armazenamento SSD',
        'Sites ilimitados',
        'Largura de banda ilimitada',
        'SSL grátis',
        'Email profissional ilimitado',
        'Backup automático diário',
        'Suporte prioritário',
        'WooCommerce incluído'
      ],
      popular: true,
      color: 'blue'
    },
    {
      name: 'Business',
      price: 'R$ 79,90',
      period: '/mês',
      description: 'Para empresas que precisam de máxima performance',
      features: [
        '100 GB de armazenamento SSD',
        'Sites ilimitados',
        'Largura de banda ilimitada',
        'SSL grátis',
        'Email profissional ilimitado',
        'Backup automático diário',
        'Suporte 24/7 por telefone',
        'CDN grátis',
        'Staging environment'
      ],
      popular: false,
      color: 'purple'
    }
  ];

  const vpsPlans = [
    {
      name: 'VPS Basic',
      price: 'R$ 89,90',
      specs: {
        cpu: '2 vCPU',
        ram: '4 GB RAM',
        storage: '80 GB SSD',
        bandwidth: '5 TB'
      }
    },
    {
      name: 'VPS Pro',
      price: 'R$ 169,90',
      specs: {
        cpu: '4 vCPU',
        ram: '8 GB RAM',
        storage: '160 GB SSD',
        bandwidth: '10 TB'
      }
    },
    {
      name: 'VPS Advanced',
      price: 'R$ 299,90',
      specs: {
        cpu: '6 vCPU',
        ram: '16 GB RAM',
        storage: '320 GB SSD',
        bandwidth: '20 TB'
      }
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Planos e Preços
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Escolha o plano ideal para suas necessidades. Todos incluem suporte especializado 
            e garantia de uptime de 99.9%.
          </p>
        </div>

        {/* Hospedagem Web Plans */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-8">Hospedagem Web</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <div key={index} className={`relative bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-1 ${plan.popular ? 'ring-2 ring-blue-600' : ''}`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-blue-600 text-white px-6 py-2 rounded-full text-sm font-semibold flex items-center space-x-1">
                      <Star className="h-4 w-4 fill-current" />
                      <span>Mais Popular</span>
                    </div>
                  </div>
                )}
                
                <div className="p-8">
                  <div className="text-center mb-8">
                    <h4 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h4>
                    <p className="text-gray-600 mb-4">{plan.description}</p>
                    <div className="mb-4">
                      <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                      <span className="text-gray-600">{plan.period}</span>
                    </div>
                  </div>

                  <ul className="space-y-4 mb-8">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center space-x-3">
                        <Check className="h-5 w-5 text-green-600 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <button className={`w-full py-3 rounded-lg font-semibold transition-all ${
                    plan.popular 
                      ? 'bg-blue-600 text-white hover:bg-blue-700 transform hover:scale-105' 
                      : 'border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white'
                  }`}>
                    Escolher Plano
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* VPS Plans */}
        <div>
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-8">Servidores VPS</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {vpsPlans.map((plan, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-1">
                <div className="p-8">
                  <div className="text-center mb-6">
                    <h4 className="text-xl font-bold text-gray-900 mb-4">{plan.name}</h4>
                    <div className="text-3xl font-bold text-gray-900 mb-6">
                      {plan.price}
                      <span className="text-base text-gray-600">/mês</span>
                    </div>
                  </div>

                  <div className="space-y-4 mb-8">
                    {Object.entries(plan.specs).map(([key, value], specIndex) => (
                      <div key={specIndex} className="flex justify-between items-center py-2 border-b border-gray-100">
                        <span className="text-gray-600 capitalize">{key.replace('_', ' ')}:</span>
                        <span className="font-semibold text-gray-900">{value}</span>
                      </div>
                    ))}
                  </div>

                  <button className="w-full bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition-colors font-semibold">
                    Contratar VPS
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 text-center">
          <p className="text-gray-600 mb-4">
            Precisa de algo personalizado?
          </p>
          <button className="bg-orange-600 text-white px-8 py-3 rounded-lg hover:bg-orange-700 transition-colors font-semibold">
            Solicitar Orçamento Personalizado
          </button>
        </div>
      </div>
    </section>
  );
};

export default Pricing;