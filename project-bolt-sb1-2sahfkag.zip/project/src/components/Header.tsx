import React from 'react';
import { Globe, Menu, X } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  return (
    <header className="bg-white shadow-sm fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-2">
            <Globe className="h-8 w-8 text-blue-600" />
            <span className="text-2xl font-bold text-gray-900">HostPro</span>
          </div>
          
          {/* Desktop Menu */}
          <nav className="hidden md:flex space-x-8">
            <a href="#home" className="text-gray-700 hover:text-blue-600 transition-colors">Início</a>
            <a href="#services" className="text-gray-700 hover:text-blue-600 transition-colors">Serviços</a>
            <a href="#pricing" className="text-gray-700 hover:text-blue-600 transition-colors">Preços</a>
            <a href="#contact" className="text-gray-700 hover:text-blue-600 transition-colors">Contato</a>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <button className="text-gray-700 hover:text-blue-600 transition-colors">
              Login
            </button>
            <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
              Começar Agora
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-gray-200">
            <div className="py-4 space-y-4">
              <a href="#home" className="block text-gray-700 hover:text-blue-600">Início</a>
              <a href="#services" className="block text-gray-700 hover:text-blue-600">Serviços</a>
              <a href="#pricing" className="block text-gray-700 hover:text-blue-600">Preços</a>
              <a href="#contact" className="block text-gray-700 hover:text-blue-600">Contato</a>
              <div className="pt-4 space-y-2">
                <button className="block w-full text-left text-gray-700 hover:text-blue-600">
                  Login
                </button>
                <button className="block w-full bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                  Começar Agora
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;