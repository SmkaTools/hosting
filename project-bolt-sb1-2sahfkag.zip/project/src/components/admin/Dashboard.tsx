import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Server, 
  CreditCard, 
  AlertTriangle, 
  TrendingUp,
  Activity,
  DollarSign,
  Ticket
} from 'lucide-react';
import { SubscriptionService } from '../../services/subscriptionService';
import { InvoiceService } from '../../services/invoiceService';
import { SupportService } from '../../services/supportService';
import { CustomerService } from '../../services/customerService';

interface DashboardStats {
  customers: number;
  subscriptions: {
    total: number;
    active: number;
    suspended: number;
    cancelled: number;
  };
  revenue: {
    monthly: number;
    total: number;
  };
  tickets: {
    open: number;
    total: number;
  };
}

const AdminDashboard = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardStats();
  }, []);

  const loadDashboardStats = async () => {
    try {
      const [
        customerStats,
        subscriptionStats,
        invoiceStats,
        ticketStats
      ] = await Promise.all([
        CustomerService.getAllCustomers(1, 1),
        SubscriptionService.getSubscriptionStats(),
        InvoiceService.getInvoiceStats(),
        SupportService.getTicketStats()
      ]);

      setStats({
        customers: customerStats.total || 0,
        subscriptions: {
          total: subscriptionStats.total,
          active: subscriptionStats.active,
          suspended: subscriptionStats.suspended,
          cancelled: subscriptionStats.cancelled
        },
        revenue: {
          monthly: invoiceStats.monthly_revenue,
          total: invoiceStats.total_revenue
        },
        tickets: {
          open: ticketStats.open + ticketStats.in_progress,
          total: ticketStats.total
        }
      });
    } catch (error) {
      console.error('Erro ao carregar estatísticas:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const statCards = [
    {
      title: 'Total de Clientes',
      value: stats?.customers || 0,
      icon: Users,
      color: 'blue',
      change: '+12%'
    },
    {
      title: 'Assinaturas Ativas',
      value: stats?.subscriptions.active || 0,
      icon: Server,
      color: 'green',
      change: '+8%'
    },
    {
      title: 'Receita Mensal',
      value: `R$ ${(stats?.revenue.monthly || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
      icon: DollarSign,
      color: 'purple',
      change: '+15%'
    },
    {
      title: 'Tickets Abertos',
      value: stats?.tickets.open || 0,
      icon: Ticket,
      color: 'orange',
      change: '-5%'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'bg-blue-500 text-blue-600 bg-blue-50',
      green: 'bg-green-500 text-green-600 bg-green-50',
      purple: 'bg-purple-500 text-purple-600 bg-purple-50',
      orange: 'bg-orange-500 text-orange-600 bg-orange-50'
    };
    return colors[color as keyof typeof colors].split(' ');
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard Administrativo</h1>
        <button 
          onClick={loadDashboardStats}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <Activity className="h-4 w-4" />
          <span>Atualizar</span>
        </button>
      </div>

      {/* Cards de Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card, index) => {
          const Icon = card.icon;
          const [bgColor, textColor, cardBg] = getColorClasses(card.color);
          
          return (
            <div key={index} className={`${cardBg} rounded-xl p-6 border border-gray-200`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">{card.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{card.value}</p>
                  <p className={`text-sm ${card.change.startsWith('+') ? 'text-green-600' : 'text-red-600'} mt-1`}>
                    {card.change} vs mês anterior
                  </p>
                </div>
                <div className={`${bgColor} p-3 rounded-lg`}>
                  <Icon className={`h-6 w-6 text-white`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Gráficos e Informações Detalhadas */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Status das Assinaturas */}
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Status das Assinaturas</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Ativas</span>
              <div className="flex items-center space-x-2">
                <div className="w-24 bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-500 h-2 rounded-full" 
                    style={{ 
                      width: `${((stats?.subscriptions.active || 0) / (stats?.subscriptions.total || 1)) * 100}%` 
                    }}
                  ></div>
                </div>
                <span className="text-sm font-medium">{stats?.subscriptions.active}</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Suspensas</span>
              <div className="flex items-center space-x-2">
                <div className="w-24 bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-orange-500 h-2 rounded-full" 
                    style={{ 
                      width: `${((stats?.subscriptions.suspended || 0) / (stats?.subscriptions.total || 1)) * 100}%` 
                    }}
                  ></div>
                </div>
                <span className="text-sm font-medium">{stats?.subscriptions.suspended}</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Canceladas</span>
              <div className="flex items-center space-x-2">
                <div className="w-24 bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-red-500 h-2 rounded-full" 
                    style={{ 
                      width: `${((stats?.subscriptions.cancelled || 0) / (stats?.subscriptions.total || 1)) * 100}%` 
                    }}
                  ></div>
                </div>
                <span className="text-sm font-medium">{stats?.subscriptions.cancelled}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Alertas e Notificações */}
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Alertas Importantes</h3>
          <div className="space-y-3">
            <div className="flex items-center space-x-3 p-3 bg-orange-50 rounded-lg">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
              <div>
                <p className="text-sm font-medium text-orange-800">Tickets Pendentes</p>
                <p className="text-xs text-orange-600">{stats?.tickets.open} tickets aguardando resposta</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
              <TrendingUp className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-sm font-medium text-blue-800">Crescimento</p>
                <p className="text-xs text-blue-600">Receita cresceu 15% este mês</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
              <CreditCard className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-sm font-medium text-green-800">Pagamentos</p>
                <p className="text-xs text-green-600">Taxa de conversão: 94%</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Ações Rápidas */}
      <div className="bg-white rounded-xl p-6 border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Ações Rápidas</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button className="p-4 text-center border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <Users className="h-6 w-6 text-blue-600 mx-auto mb-2" />
            <span className="text-sm font-medium">Gerenciar Clientes</span>
          </button>
          <button className="p-4 text-center border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <Server className="h-6 w-6 text-green-600 mx-auto mb-2" />
            <span className="text-sm font-medium">Ver Serviços</span>
          </button>
          <button className="p-4 text-center border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <CreditCard className="h-6 w-6 text-purple-600 mx-auto mb-2" />
            <span className="text-sm font-medium">Faturas</span>
          </button>
          <button className="p-4 text-center border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <Ticket className="h-6 w-6 text-orange-600 mx-auto mb-2" />
            <span className="text-sm font-medium">Suporte</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;