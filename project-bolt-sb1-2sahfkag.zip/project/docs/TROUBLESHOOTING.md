# 🚨 Guia de Solução de Problemas
## Sistema de Hospedagem - Ubuntu 24.04

Soluções para os problemas mais comuns encontrados durante a instalação e operação.

---

## 🔍 Diagnóstico Rápido

### Script de Diagnóstico
```bash
#!/bin/bash
echo "=== DIAGNÓSTICO RÁPIDO ==="
echo "Data: $(date)"
echo "Sistema: $(uname -a)"
echo "Uptime: $(uptime)"
echo

echo "=== SERVIÇOS ==="
echo "Nginx: $(systemctl is-active nginx)"
echo "UFW: $(systemctl is-active ufw)"
echo

echo "=== APLICAÇÃO ==="
pm2 status 2>/dev/null || echo "PM2 não encontrado"
echo

echo "=== RECURSOS ==="
echo "CPU: $(top -bn1 | grep "Cpu(s)" | awk '{print $2}')"
echo "Memória: $(free | grep Mem | awk '{printf("%.1f%% usado", $3/$2 * 100.0)}')"
echo "Disco: $(df -h / | awk 'NR==2{printf "%s usado", $5}')"
echo

echo "=== CONECTIVIDADE ==="
curl -I -s http://localhost 2>/dev/null | head -1 || echo "HTTP não responde"
curl -I -s https://localhost 2>/dev/null | head -1 || echo "HTTPS não responde"
```

---

## 🌐 Problemas de Conectividade

### 1. Erro 502 Bad Gateway

**Sintomas:**
- Página mostra "502 Bad Gateway"
- Nginx está rodando mas aplicação não responde

**Diagnóstico:**
```bash
# Verificar status dos serviços
sudo systemctl status nginx
pm2 status

# Verificar logs
sudo tail -f /var/log/nginx/error.log
pm2 logs hostpro-app
```

**Soluções:**

**A) Aplicação não está rodando:**
```bash
# Iniciar aplicação
cd ~/hostpro-app
pm2 start ecosystem.config.js

# Verificar se iniciou
pm2 status
```

**B) Porta incorreta na configuração:**
```bash
# Verificar porta da aplicação
grep -n "PORT" ~/hostpro-app/.env
grep -n "listen" /etc/nginx/sites-available/hostpro

# Corrigir se necessário
nano ~/hostpro-app/.env  # PORT=3000
nano /etc/nginx/sites-available/hostpro  # proxy_pass http://localhost:3000
```

**C) Aplicação crashando:**
```bash
# Ver logs de erro
pm2 logs hostpro-app --err

# Reiniciar com mais memória
pm2 delete hostpro-app
pm2 start ecosystem.config.js --max-memory-restart 2G
```

### 2. Erro 404 Not Found

**Sintomas:**
- Página inicial carrega mas rotas internas dão 404
- SPA não funciona corretamente

**Solução:**
```bash
# Verificar configuração do Nginx para SPA
sudo nano /etc/nginx/sites-available/hostpro

# Adicionar/verificar esta configuração:
location / {
    try_files $uri $uri/ /index.html;
}

# Recarregar Nginx
sudo nginx -t && sudo systemctl reload nginx
```

### 3. Erro de SSL/HTTPS

**Sintomas:**
- "Your connection is not private"
- Certificado expirado ou inválido

**Diagnóstico:**
```bash
# Verificar certificado
sudo certbot certificates

# Verificar expiração
echo | openssl s_client -servername SEU_DOMINIO.com -connect SEU_DOMINIO.com:443 2>/dev/null | openssl x509 -noout -dates
```

**Soluções:**

**A) Renovar certificado:**
```bash
# Renovar manualmente
sudo certbot renew

# Forçar renovação
sudo certbot renew --force-renewal

# Recarregar Nginx
sudo systemctl reload nginx
```

**B) Recriar certificado:**
```bash
# Remover certificado atual
sudo certbot delete --cert-name SEU_DOMINIO.com

# Criar novo
sudo certbot --nginx -d SEU_DOMINIO.com -d www.SEU_DOMINIO.com
```

---

## 🖥️ Problemas de Performance

### 1. Alto Uso de CPU

**Diagnóstico:**
```bash
# Verificar processos
top -c
htop  # se instalado

# Verificar uso por aplicação
pm2 monit
```

**Soluções:**

**A) Otimizar aplicação:**
```bash
# Aumentar instâncias do PM2
pm2 scale hostpro-app +1

# Ou configurar cluster mode
pm2 delete hostpro-app
pm2 start ecosystem.config.js --instances max
```

**B) Limitar recursos:**
```bash
# Editar configuração do PM2
nano ~/hostpro-app/ecosystem.config.js

# Adicionar limites:
max_memory_restart: '512M',
max_restarts: 10,
min_uptime: '10s'
```

### 2. Alto Uso de Memória

**Diagnóstico:**
```bash
# Verificar uso de memória
free -h
ps aux --sort=-%mem | head -10
```

**Soluções:**

**A) Configurar swap:**
```bash
# Criar arquivo de swap (2GB)
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile

# Tornar permanente
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

**B) Otimizar aplicação:**
```bash
# Reiniciar aplicação periodicamente
pm2 start ecosystem.config.js --cron-restart="0 2 * * *"

# Configurar limite de memória
pm2 start ecosystem.config.js --max-memory-restart 1G
```

### 3. Lentidão no Site

**Diagnóstico:**
```bash
# Testar velocidade
curl -w "@curl-format.txt" -o /dev/null -s "https://SEU_DOMINIO.com"

# Criar arquivo curl-format.txt:
cat > curl-format.txt << 'EOF'
     time_namelookup:  %{time_namelookup}\n
        time_connect:  %{time_connect}\n
     time_appconnect:  %{time_appconnect}\n
    time_pretransfer:  %{time_pretransfer}\n
       time_redirect:  %{time_redirect}\n
  time_starttransfer:  %{time_starttransfer}\n
                     ----------\n
          time_total:  %{time_total}\n
EOF
```

**Soluções:**

**A) Configurar cache no Nginx:**
```bash
sudo nano /etc/nginx/sites-available/hostpro

# Adicionar configurações de cache:
location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
    add_header Vary Accept-Encoding;
}

# Habilitar compressão
location / {
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
    try_files $uri $uri/ /index.html;
}
```

**B) Otimizar build:**
```bash
cd ~/hostpro-app

# Verificar tamanho do build
du -sh dist/

# Analisar bundle
npm run build -- --analyze  # se disponível
```

---

## 🗄️ Problemas de Banco de Dados

### 1. Erro de Conexão com Supabase

**Sintomas:**
- "Failed to fetch"
- Timeout de conexão
- Dados não carregam

**Diagnóstico:**
```bash
# Verificar variáveis de ambiente
cat ~/hostpro-app/.env

# Testar conectividade
curl -I "https://SEU_PROJETO.supabase.co/rest/v1/" \
  -H "apikey: SUA_CHAVE_ANONIMA"
```

**Soluções:**

**A) Verificar configurações:**
```bash
# Verificar URL e chave
nano ~/hostpro-app/.env

# Formato correto:
VITE_SUPABASE_URL=https://seuprojetoid.supabase.co
VITE_SUPABASE_ANON_KEY=sua.chave.anonima.aqui
```

**B) Verificar RLS (Row Level Security):**
- Acesse o painel do Supabase
- Vá em Authentication > Policies
- Verifique se as políticas estão corretas

**C) Verificar CORS:**
- No painel do Supabase
- Vá em Settings > API
- Adicione seu domínio em "CORS origins"

### 2. Erro de Autenticação

**Sintomas:**
- Login não funciona
- "Invalid login credentials"
- Usuário não consegue se registrar

**Soluções:**

**A) Verificar configurações de auth:**
- Painel Supabase > Authentication > Settings
- Site URL: `https://SEU_DOMINIO.com`
- Redirect URLs: `https://SEU_DOMINIO.com/**`

**B) Verificar email confirmation:**
- Se habilitado, usuários precisam confirmar email
- Para desenvolvimento, pode desabilitar

---

## 📁 Problemas de Arquivos

### 1. Permissões Incorretas

**Sintomas:**
- "Permission denied"
- Arquivos não podem ser lidos/escritos

**Soluções:**
```bash
# Corrigir permissões da aplicação
sudo chown -R $(whoami):$(whoami) ~/hostpro-app
chmod -R 755 ~/hostpro-app

# Corrigir permissões dos logs
sudo chown -R $(whoami):$(whoami) ~/logs
chmod -R 644 ~/logs/*.log

# Corrigir permissões do Nginx (se necessário)
sudo chown -R www-data:www-data /var/log/nginx/
```

### 2. Espaço em Disco Insuficiente

**Diagnóstico:**
```bash
# Verificar uso do disco
df -h

# Encontrar arquivos grandes
du -h --max-depth=1 / | sort -hr | head -10
```

**Soluções:**

**A) Limpar logs antigos:**
```bash
# Limpar logs do sistema
sudo journalctl --vacuum-time=7d

# Limpar logs do Nginx
sudo find /var/log/nginx/ -name "*.log" -mtime +7 -delete

# Limpar logs do PM2
pm2 flush
```

**B) Limpar cache e temporários:**
```bash
# Limpar cache do npm
npm cache clean --force

# Limpar arquivos temporários
sudo apt autoremove -y
sudo apt autoclean
```

---

## 🔧 Problemas de Configuração

### 1. Nginx não Inicia

**Diagnóstico:**
```bash
# Verificar status
sudo systemctl status nginx

# Testar configuração
sudo nginx -t

# Ver logs de erro
sudo journalctl -u nginx -f
```

**Soluções:**

**A) Erro de sintaxe:**
```bash
# Verificar configuração
sudo nginx -t

# Se houver erro, editar arquivo
sudo nano /etc/nginx/sites-available/hostpro

# Verificar novamente
sudo nginx -t
```

**B) Porta já em uso:**
```bash
# Verificar o que está usando a porta 80/443
sudo netstat -tlnp | grep :80
sudo netstat -tlnp | grep :443

# Parar serviço conflitante se necessário
sudo systemctl stop apache2  # exemplo
```

### 2. PM2 não Funciona

**Diagnóstico:**
```bash
# Verificar instalação
pm2 --version

# Verificar processos
pm2 status

# Ver logs
pm2 logs
```

**Soluções:**

**A) Reinstalar PM2:**
```bash
# Remover instalação atual
sudo npm uninstall -g pm2

# Reinstalar
sudo npm install -g pm2

# Reconfigurar startup
pm2 startup
```

**B) Problemas de permissão:**
```bash
# Verificar proprietário dos arquivos PM2
ls -la ~/.pm2/

# Corrigir se necessário
sudo chown -R $(whoami):$(whoami) ~/.pm2/
```

---

## 🚨 Recuperação de Emergência

### 1. Site Completamente Fora do Ar

**Passos de recuperação:**

```bash
# 1. Verificar serviços básicos
sudo systemctl status nginx
sudo systemctl status ufw

# 2. Reiniciar serviços se necessário
sudo systemctl restart nginx
pm2 restart all

# 3. Verificar logs
sudo tail -50 /var/log/nginx/error.log
pm2 logs --lines 50

# 4. Restaurar backup se necessário
cd ~/backups
ls -la  # encontrar backup mais recente
tar -xzf app_YYYYMMDD_HHMMSS.tar.gz -C ~/hostpro-app-restore/

# 5. Testar conectividade
curl -I http://localhost
curl -I https://SEU_DOMINIO.com
```

### 2. Corrupção de Dados

**Recuperação:**

```bash
# 1. Parar aplicação
pm2 stop all

# 2. Fazer backup do estado atual
tar -czf ~/emergency_backup_$(date +%Y%m%d_%H%M%S).tar.gz ~/hostpro-app

# 3. Restaurar do backup
cd ~/backups
tar -xzf BACKUP_MAIS_RECENTE.tar.gz -C ~/

# 4. Verificar integridade
cd ~/hostpro-app
npm install
npm run build

# 5. Reiniciar
pm2 start ecosystem.config.js
```

---

## 📞 Quando Buscar Ajuda

### Informações para Coleta

Antes de buscar suporte, colete estas informações:

```bash
# Criar relatório de erro
cat > ~/error_report.txt << EOF
=== RELATÓRIO DE ERRO ===
Data: $(date)
Sistema: $(uname -a)
Uptime: $(uptime)

=== SERVIÇOS ===
$(sudo systemctl status nginx --no-pager)

$(pm2 status)

=== LOGS RECENTES ===
Nginx Error:
$(sudo tail -20 /var/log/nginx/error.log)

PM2 Logs:
$(pm2 logs --lines 20 --nostream)

=== CONFIGURAÇÃO ===
$(cat ~/hostpro-app/.env | sed 's/=.*/=***/')

=== RECURSOS ===
$(free -h)
$(df -h)
EOF

echo "Relatório salvo em: ~/error_report.txt"
```

### Logs Importantes

```bash
# Localização dos logs principais
echo "Logs do sistema:"
echo "- Nginx: /var/log/nginx/"
echo "- Sistema: /var/log/syslog"
echo "- Auth: /var/log/auth.log"
echo "- PM2: ~/.pm2/logs/"
echo "- Aplicação: ~/logs/"
```

---

## ✅ Checklist de Verificação

### Verificação Diária
- [ ] Site acessível via HTTPS
- [ ] Aplicação respondendo corretamente
- [ ] Certificado SSL válido
- [ ] Uso de recursos dentro do normal
- [ ] Logs sem erros críticos

### Verificação Semanal
- [ ] Backups funcionando
- [ ] Atualizações de segurança
- [ ] Limpeza de logs antigos
- [ ] Verificação de espaço em disco
- [ ] Teste de recuperação

### Verificação Mensal
- [ ] Renovação de certificados
- [ ] Auditoria de segurança
- [ ] Otimização de performance
- [ ] Revisão de configurações
- [ ] Teste completo do sistema

---

*Guia de solução de problemas - Ubuntu 24.04 LTS - Versão 1.0*