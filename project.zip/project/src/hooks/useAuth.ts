import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { CustomerService } from '../services/customerService';
import type { User } from '@supabase/supabase-js';
import type { Customer } from '../lib/supabase';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Verificar sessão atual
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        loadCustomerData(session.user.id);
      } else {
        setLoading(false);
      }
    });

    // Escutar mudanças de autenticação
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setUser(session?.user ?? null);
        if (session?.user) {
          await loadCustomerData(session.user.id);
        } else {
          setCustomer(null);
          setLoading(false);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const loadCustomerData = async (userId: string) => {
    try {
      const customerData = await CustomerService.getCustomerByUserId(userId);
      setCustomer(customerData);
    } catch (error) {
      console.error('Erro ao carregar dados do cliente:', error);
      setCustomer(null);
    } finally {
      setLoading(false);
    }
  };

  const signUp = async (email: string, password: string, customerData: {
    contact_name: string;
    company_name?: string;
    phone?: string;
  }) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) throw error;

    if (data.user) {
      // Criar registro do cliente
      const customer = await CustomerService.createCustomer({
        user_id: data.user.id,
        email,
        ...customerData,
        is_active: true
      });
      setCustomer(customer);
    }

    return data;
  };

  const signIn = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) throw error;
    return data;
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  };

  const resetPassword = async (email: string) => {
    const { error } = await supabase.auth.resetPasswordForEmail(email);
    if (error) throw error;
  };

  const updateProfile = async (updates: Partial<Customer>) => {
    if (!customer) throw new Error('Cliente não encontrado');
    
    const updatedCustomer = await CustomerService.updateCustomer(customer.id, updates);
    setCustomer(updatedCustomer);
    return updatedCustomer;
  };

  return {
    user,
    customer,
    loading,
    signUp,
    signIn,
    signOut,
    resetPassword,
    updateProfile,
    isAuthenticated: !!user,
    isCustomerComplete: !!customer
  };
}