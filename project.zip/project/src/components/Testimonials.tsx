import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: 'Maria Silva',
      role: 'CEO, Loja Fashion',
      content: 'A HostPro transformou nosso e-commerce. A velocidade do site aumentou 300% e as vendas dispararam. Suporte excepcional!',
      rating: 5,
      image: 'https://images.pexels.com/photos/3823207/pexels-photo-3823207.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
    },
    {
      name: 'João Santos',
      role: 'Desenvolvedor Freelancer',
      content: 'Uso a HostPro para todos os meus clientes. A estabilidade é impressionante e nunca tive problemas. Recomendo de olhos fechados!',
      rating: 5,
      image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
    },
    {
      name: 'Ana Costa',
      role: 'Agência Digital',
      content: 'Migramos mais de 50 sites para a HostPro. O processo foi suave e o resultado superou expectativas. Parceria de confiança!',
      rating: 5,
      image: 'https://images.pexels.com/photos/3783725/pexels-photo-3783725.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
    },
    {
      name: 'Carlos Mendes',
      role: 'Startup TechNova',
      content: 'O VPS da HostPro nos deu a flexibilidade que precisávamos para escalar. Performance excepcional com custo acessível.',
      rating: 5,
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
    },
    {
      name: 'Luciana Oliveira',
      role: 'Blog Culinário',
      content: 'Meu blog nunca esteve tão rápido! A migração foi gratuita e o suporte me ajudou em cada passo. Serviço impecável.',
      rating: 5,
      image: 'https://images.pexels.com/photos/3823488/pexels-photo-3823488.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
    },
    {
      name: 'Ricardo Ferreira',
      role: 'E-commerce Manager',
      content: 'A infraestrutura da HostPro suporta nossos picos de tráfego sem problemas. ROI excelente e suporte sempre disponível.',
      rating: 5,
      image: 'https://images.pexels.com/photos/2773977/pexels-photo-2773977.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            O Que Nossos Clientes Dizem
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Mais de 10.000 clientes confiam na HostPro para suas soluções de hospedagem. 
            Veja o que eles têm a dizer sobre nossos serviços.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 p-8 relative overflow-hidden">
              <div className="absolute top-4 right-4 text-blue-600 opacity-20">
                <Quote className="h-8 w-8" />
              </div>
              
              <div className="flex items-center mb-6">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                  <p className="text-sm text-gray-600">{testimonial.role}</p>
                </div>
              </div>

              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
              </div>

              <p className="text-gray-700 leading-relaxed italic">
                "{testimonial.content}"
              </p>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">
              Junte-se a Mais de 10.000 Clientes Satisfeitos
            </h3>
            <p className="text-xl mb-6 opacity-90">
              Comece sua jornada digital conosco hoje mesmo
            </p>
            <button className="bg-white text-blue-600 px-8 py-3 rounded-lg hover:bg-gray-100 transition-colors font-semibold text-lg">
              Começar Agora - Grátis por 30 Dias
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;