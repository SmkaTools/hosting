import React from 'react';
import { Globe, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-6">
            <div className="flex items-center space-x-2">
              <Globe className="h-8 w-8 text-blue-400" />
              <span className="text-2xl font-bold">HostPro</span>
            </div>
            <p className="text-gray-300 leading-relaxed">
              Líder em soluções de hospedagem no Brasil. Oferecemos serviços confiáveis 
              e suporte especializado para impulsionar seu sucesso online.
            </p>
            <div className="flex space-x-4">
              {[Facebook, Twitter, Instagram, Linkedin].map((Social, index) => (
                <a key={index} href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                  <Social className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Serviços</h3>
            <ul className="space-y-3">
              {[
                'Hospedagem Compartilhada',
                'Hospedagem WordPress',
                'Loja Virtual',
                'Servidores VPS',
                'Servidores Dedicados',
                'Email Profissional',
                'Registro de Domínio',
                'SSL Certificates'
              ].map((service, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors">
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Suporte</h3>
            <ul className="space-y-3">
              {[
                'Central de Ajuda',
                'Documentação',
                'Tutoriais',
                'Status do Sistema',
                'Migração Gratuita',
                'Garantia de Uptime',
                'Política de Reembolso',
                'Termos de Serviço'
              ].map((item, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Contato</h3>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-blue-400" />
                <div>
                  <p className="text-gray-300">(11) 4000-0000</p>
                  <p className="text-sm text-gray-400">Seg-Dom, 24h</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-blue-400" />
                <div>
                  <p className="text-gray-300">contato@hostpro.com.br</p>
                  <p className="text-sm text-gray-400">Resposta em 1h</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-blue-400" />
                <div>
                  <p className="text-gray-300">São Paulo, SP</p>
                  <p className="text-sm text-gray-400">Data Center Nacional</p>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 bg-blue-600 rounded-lg">
              <h4 className="font-semibold mb-2">Suporte 24/7</h4>
              <p className="text-sm text-blue-100 mb-3">
                Nossa equipe está sempre disponível para ajudar
              </p>
              <button className="bg-white text-blue-600 px-4 py-2 rounded font-semibold text-sm hover:bg-gray-100 transition-colors w-full">
                Chat Online
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2025 HostPro. Todos os direitos reservados.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-blue-400 text-sm transition-colors">
                Política de Privacidade
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 text-sm transition-colors">
                Termos de Uso
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 text-sm transition-colors">
                Cookies
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;