import { supabase } from '../lib/supabase';
import type { Invoice } from '../lib/supabase';

export class InvoiceService {
  // Criar nova fatura
  static async createInvoice(invoiceData: Omit<Invoice, 'id' | 'created_at' | 'updated_at' | 'invoice_number'>) {
    // Gerar número da fatura
    const invoiceNumber = await this.generateInvoiceNumber();
    
    const { data, error } = await supabase
      .from('invoices')
      .insert([{ ...invoiceData, invoice_number: invoiceNumber }])
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Gerar número sequencial da fatura
  private static async generateInvoiceNumber(): Promise<string> {
    const { data, error } = await supabase
      .from('invoices')
      .select('invoice_number')
      .order('created_at', { ascending: false })
      .limit(1);

    if (error) throw error;

    let nextNumber = 1;
    if (data && data.length > 0) {
      const lastNumber = parseInt(data[0].invoice_number.replace('INV', ''));
      nextNumber = lastNumber + 1;
    }

    return `INV${nextNumber.toString().padStart(6, '0')}`;
  }

  // Buscar faturas do cliente
  static async getCustomerInvoices(customerId: string) {
    const { data, error } = await supabase
      .from('invoices')
      .select('*')
      .eq('customer_id', customerId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  }

  // Buscar fatura por ID
  static async getInvoiceById(id: string) {
    const { data, error } = await supabase
      .from('invoices')
      .select(`
        *,
        customers(contact_name, email, company_name, address),
        subscriptions(service_type)
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  }

  // Marcar fatura como paga
  static async markInvoiceAsPaid(id: string, paymentMethod: string) {
    const { data, error } = await supabase
      .from('invoices')
      .update({ 
        status: 'completed',
        paid_at: new Date().toISOString(),
        payment_method: paymentMethod
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Buscar faturas em atraso
  static async getOverdueInvoices() {
    const today = new Date().toISOString().split('T')[0];
    
    const { data, error } = await supabase
      .from('invoices')
      .select(`
        *,
        customers(contact_name, email, company_name)
      `)
      .eq('status', 'pending')
      .lt('due_date', today)
      .order('due_date', { ascending: true });

    if (error) throw error;
    return data;
  }

  // Buscar faturas que vencem em breve
  static async getUpcomingInvoices(days = 7) {
    const today = new Date();
    const futureDate = new Date();
    futureDate.setDate(today.getDate() + days);

    const { data, error } = await supabase
      .from('invoices')
      .select(`
        *,
        customers(contact_name, email, company_name)
      `)
      .eq('status', 'pending')
      .gte('due_date', today.toISOString().split('T')[0])
      .lte('due_date', futureDate.toISOString().split('T')[0])
      .order('due_date', { ascending: true });

    if (error) throw error;
    return data;
  }

  // Buscar todas as faturas (admin)
  static async getAllInvoices(page = 1, limit = 10, filters?: {
    status?: string;
    customer_id?: string;
  }) {
    const offset = (page - 1) * limit;
    
    let query = supabase
      .from('invoices')
      .select(`
        *,
        customers(contact_name, email, company_name)
      `, { count: 'exact' });

    if (filters?.status) {
      query = query.eq('status', filters.status);
    }
    if (filters?.customer_id) {
      query = query.eq('customer_id', filters.customer_id);
    }

    const { data, error, count } = await query
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;
    return { invoices: data, total: count };
  }

  // Estatísticas de faturas
  static async getInvoiceStats() {
    const { data, error } = await supabase
      .from('invoices')
      .select('status, total_amount, created_at');

    if (error) throw error;

    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();

    const stats = {
      total: data.length,
      pending: data.filter(i => i.status === 'pending').length,
      completed: data.filter(i => i.status === 'completed').length,
      failed: data.filter(i => i.status === 'failed').length,
      overdue: data.filter(i => {
        const dueDate = new Date(i.created_at);
        return i.status === 'pending' && dueDate < new Date();
      }).length,
      monthly_revenue: data
        .filter(i => {
          const invoiceDate = new Date(i.created_at);
          return i.status === 'completed' && 
                 invoiceDate.getMonth() === currentMonth && 
                 invoiceDate.getFullYear() === currentYear;
        })
        .reduce((sum, i) => sum + parseFloat(i.total_amount), 0),
      total_revenue: data
        .filter(i => i.status === 'completed')
        .reduce((sum, i) => sum + parseFloat(i.total_amount), 0)
    };

    return stats;
  }

  // Criar fatura recorrente para assinatura
  static async createRecurringInvoice(subscriptionId: string) {
    const { data: subscription, error: subError } = await supabase
      .from('subscriptions')
      .select(`
        *,
        customers(*)
      `)
      .eq('id', subscriptionId)
      .single();

    if (subError) throw subError;

    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 30); // 30 dias para pagamento

    const invoiceData = {
      customer_id: subscription.customer_id,
      subscription_id: subscriptionId,
      amount: subscription.price,
      tax_amount: subscription.price * 0.18, // 18% de imposto
      total_amount: subscription.price * 1.18,
      currency: 'BRL',
      due_date: dueDate.toISOString(),
      status: 'pending' as const,
      items: [{
        description: `Assinatura ${subscription.service_type}`,
        quantity: 1,
        unit_price: subscription.price,
        total: subscription.price
      }]
    };

    return this.createInvoice(invoiceData);
  }
}