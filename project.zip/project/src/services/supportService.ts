import { supabase } from '../lib/supabase';
import type { SupportTicket } from '../lib/supabase';

export class SupportService {
  // Criar novo ticket
  static async createTicket(ticketData: Omit<SupportTicket, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('support_tickets')
      .insert([ticketData])
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Buscar tickets do cliente
  static async getCustomerTickets(customerId: string) {
    const { data, error } = await supabase
      .from('support_tickets')
      .select('*')
      .eq('customer_id', customerId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  }

  // Buscar ticket por ID
  static async getTicketById(id: string) {
    const { data, error } = await supabase
      .from('support_tickets')
      .select(`
        *,
        customers(contact_name, email, company_name)
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  }

  // Buscar mensagens do ticket
  static async getTicketMessages(ticketId: string) {
    const { data, error } = await supabase
      .from('ticket_messages')
      .select(`
        *,
        sender:auth.users(email)
      `)
      .eq('ticket_id', ticketId)
      .order('created_at', { ascending: true });

    if (error) throw error;
    return data;
  }

  // Adicionar mensagem ao ticket
  static async addTicketMessage(ticketId: string, senderId: string, message: string, isInternal = false) {
    const { data, error } = await supabase
      .from('ticket_messages')
      .insert([{
        ticket_id: ticketId,
        sender_id: senderId,
        message,
        is_internal: isInternal
      }])
      .select()
      .single();

    if (error) throw error;

    // Atualizar timestamp do ticket
    await supabase
      .from('support_tickets')
      .update({ updated_at: new Date().toISOString() })
      .eq('id', ticketId);

    return data;
  }

  // Atualizar status do ticket
  static async updateTicketStatus(id: string, status: SupportTicket['status']) {
    const updates: any = { status };
    
    if (status === 'resolved' || status === 'closed') {
      updates.resolved_at = new Date().toISOString();
    }

    const { data, error } = await supabase
      .from('support_tickets')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Atualizar prioridade do ticket
  static async updateTicketPriority(id: string, priority: SupportTicket['priority']) {
    const { data, error } = await supabase
      .from('support_tickets')
      .update({ priority })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Atribuir ticket a um agente
  static async assignTicket(id: string, assignedTo: string) {
    const { data, error } = await supabase
      .from('support_tickets')
      .update({ 
        assigned_to: assignedTo,
        status: 'in_progress'
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Buscar todos os tickets (admin)
  static async getAllTickets(page = 1, limit = 10, filters?: {
    status?: string;
    priority?: string;
    assigned_to?: string;
  }) {
    const offset = (page - 1) * limit;
    
    let query = supabase
      .from('support_tickets')
      .select(`
        *,
        customers(contact_name, email, company_name)
      `, { count: 'exact' });

    if (filters?.status) {
      query = query.eq('status', filters.status);
    }
    if (filters?.priority) {
      query = query.eq('priority', filters.priority);
    }
    if (filters?.assigned_to) {
      query = query.eq('assigned_to', filters.assigned_to);
    }

    const { data, error, count } = await query
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;
    return { tickets: data, total: count };
  }

  // Estatísticas de tickets
  static async getTicketStats() {
    const { data, error } = await supabase
      .from('support_tickets')
      .select('status, priority, created_at, resolved_at');

    if (error) throw error;

    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    const stats = {
      total: data.length,
      open: data.filter(t => t.status === 'open').length,
      in_progress: data.filter(t => t.status === 'in_progress').length,
      resolved: data.filter(t => t.status === 'resolved').length,
      closed: data.filter(t => t.status === 'closed').length,
      by_priority: {
        low: data.filter(t => t.priority === 'low').length,
        medium: data.filter(t => t.priority === 'medium').length,
        high: data.filter(t => t.priority === 'high').length,
        urgent: data.filter(t => t.priority === 'urgent').length,
      },
      monthly_created: data.filter(t => {
        const createdDate = new Date(t.created_at);
        return createdDate.getMonth() === currentMonth && 
               createdDate.getFullYear() === currentYear;
      }).length,
      monthly_resolved: data.filter(t => {
        if (!t.resolved_at) return false;
        const resolvedDate = new Date(t.resolved_at);
        return resolvedDate.getMonth() === currentMonth && 
               resolvedDate.getFullYear() === currentYear;
      }).length,
      avg_resolution_time: this.calculateAverageResolutionTime(data)
    };

    return stats;
  }

  private static calculateAverageResolutionTime(tickets: any[]): number {
    const resolvedTickets = tickets.filter(t => t.resolved_at);
    if (resolvedTickets.length === 0) return 0;

    const totalTime = resolvedTickets.reduce((sum, ticket) => {
      const created = new Date(ticket.created_at);
      const resolved = new Date(ticket.resolved_at);
      return sum + (resolved.getTime() - created.getTime());
    }, 0);

    // Retorna em horas
    return Math.round(totalTime / (1000 * 60 * 60) / resolvedTickets.length);
  }

  // Buscar tickets não atribuídos
  static async getUnassignedTickets() {
    const { data, error } = await supabase
      .from('support_tickets')
      .select(`
        *,
        customers(contact_name, email, company_name)
      `)
      .is('assigned_to', null)
      .in('status', ['open', 'in_progress'])
      .order('priority', { ascending: false })
      .order('created_at', { ascending: true });

    if (error) throw error;
    return data;
  }
}