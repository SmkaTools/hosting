import { supabase } from '../lib/supabase';

export class ActivityService {
  // Registrar atividade
  static async logActivity(data: {
    customer_id?: string;
    user_id?: string;
    action: string;
    resource_type?: string;
    resource_id?: string;
    details?: any;
    ip_address?: string;
    user_agent?: string;
  }) {
    const { error } = await supabase
      .from('activity_logs')
      .insert([{
        ...data,
        created_at: new Date().toISOString()
      }]);

    if (error) throw error;
  }

  // Buscar atividades do cliente
  static async getCustomerActivities(customerId: string, page = 1, limit = 20) {
    const offset = (page - 1) * limit;
    
    const { data, error, count } = await supabase
      .from('activity_logs')
      .select('*', { count: 'exact' })
      .eq('customer_id', customerId)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;
    return { activities: data, total: count };
  }

  // Buscar todas as atividades (admin)
  static async getAllActivities(page = 1, limit = 50, filters?: {
    customer_id?: string;
    action?: string;
    resource_type?: string;
    date_from?: string;
    date_to?: string;
  }) {
    const offset = (page - 1) * limit;
    
    let query = supabase
      .from('activity_logs')
      .select(`
        *,
        customers(contact_name, email, company_name)
      `, { count: 'exact' });

    if (filters?.customer_id) {
      query = query.eq('customer_id', filters.customer_id);
    }
    if (filters?.action) {
      query = query.ilike('action', `%${filters.action}%`);
    }
    if (filters?.resource_type) {
      query = query.eq('resource_type', filters.resource_type);
    }
    if (filters?.date_from) {
      query = query.gte('created_at', filters.date_from);
    }
    if (filters?.date_to) {
      query = query.lte('created_at', filters.date_to);
    }

    const { data, error, count } = await query
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;
    return { activities: data, total: count };
  }

  // Estatísticas de atividades
  static async getActivityStats(days = 30) {
    const fromDate = new Date();
    fromDate.setDate(fromDate.getDate() - days);

    const { data, error } = await supabase
      .from('activity_logs')
      .select('action, resource_type, created_at')
      .gte('created_at', fromDate.toISOString());

    if (error) throw error;

    const stats = {
      total: data.length,
      by_action: this.groupBy(data, 'action'),
      by_resource: this.groupBy(data, 'resource_type'),
      daily_activity: this.groupByDay(data, days)
    };

    return stats;
  }

  private static groupBy(array: any[], key: string) {
    return array.reduce((groups, item) => {
      const value = item[key] || 'unknown';
      groups[value] = (groups[value] || 0) + 1;
      return groups;
    }, {});
  }

  private static groupByDay(array: any[], days: number) {
    const dailyStats: { [key: string]: number } = {};
    
    // Inicializar todos os dias com 0
    for (let i = 0; i < days; i++) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateKey = date.toISOString().split('T')[0];
      dailyStats[dateKey] = 0;
    }

    // Contar atividades por dia
    array.forEach(item => {
      const dateKey = item.created_at.split('T')[0];
      if (dailyStats.hasOwnProperty(dateKey)) {
        dailyStats[dateKey]++;
      }
    });

    return dailyStats;
  }

  // Ações comuns para logging
  static async logLogin(customerId: string, userId: string, ipAddress?: string, userAgent?: string) {
    return this.logActivity({
      customer_id: customerId,
      user_id: userId,
      action: 'user_login',
      ip_address: ipAddress,
      user_agent: userAgent
    });
  }

  static async logSubscriptionCreated(customerId: string, subscriptionId: string, serviceType: string) {
    return this.logActivity({
      customer_id: customerId,
      action: 'subscription_created',
      resource_type: 'subscription',
      resource_id: subscriptionId,
      details: { service_type: serviceType }
    });
  }

  static async logPaymentProcessed(customerId: string, invoiceId: string, amount: number) {
    return this.logActivity({
      customer_id: customerId,
      action: 'payment_processed',
      resource_type: 'invoice',
      resource_id: invoiceId,
      details: { amount }
    });
  }

  static async logTicketCreated(customerId: string, ticketId: string, subject: string) {
    return this.logActivity({
      customer_id: customerId,
      action: 'ticket_created',
      resource_type: 'support_ticket',
      resource_id: ticketId,
      details: { subject }
    });
  }

  static async logServiceSuspended(customerId: string, subscriptionId: string, reason: string) {
    return this.logActivity({
      customer_id: customerId,
      action: 'service_suspended',
      resource_type: 'subscription',
      resource_id: subscriptionId,
      details: { reason }
    });
  }
}