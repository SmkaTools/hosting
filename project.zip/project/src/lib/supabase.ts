import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface Customer {
  id: string;
  user_id: string;
  company_name?: string;
  contact_name: string;
  email: string;
  phone?: string;
  document?: string;
  address?: any;
  billing_address?: any;
  created_at: string;
  updated_at: string;
  is_active: boolean;
  notes?: string;
}

export interface HostingPlan {
  id: string;
  name: string;
  description?: string;
  price: number;
  billing_cycle: string;
  features: any;
  limits?: any;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface VPSPlan {
  id: string;
  name: string;
  description?: string;
  price: number;
  billing_cycle: string;
  specs: any;
  features?: any;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface EcommercePlan {
  id: string;
  name: string;
  description?: string;
  price: number;
  billing_cycle: string;
  features: any;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Subscription {
  id: string;
  customer_id: string;
  service_type: 'hosting' | 'vps' | 'ecommerce' | 'domain';
  plan_id: string;
  status: 'active' | 'suspended' | 'cancelled' | 'pending';
  started_at: string;
  expires_at?: string;
  auto_renew: boolean;
  price: number;
  billing_cycle: string;
  metadata?: any;
  created_at: string;
  updated_at: string;
}

export interface Invoice {
  id: string;
  customer_id: string;
  subscription_id?: string;
  invoice_number: string;
  amount: number;
  tax_amount: number;
  total_amount: number;
  currency: string;
  due_date: string;
  paid_at?: string;
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  items: any;
  payment_method?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface SupportTicket {
  id: string;
  customer_id: string;
  subject: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  category?: string;
  assigned_to?: string;
  created_at: string;
  updated_at: string;
  resolved_at?: string;
}