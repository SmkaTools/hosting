/*
  # Sistema de Gerenciamento de Hospedagem - Schema Completo

  1. Tabelas Principais
    - `customers` - Dados dos clientes
    - `hosting_plans` - Planos de hospedagem disponíveis
    - `vps_plans` - Planos VPS disponíveis
    - `ecommerce_plans` - Planos de loja virtual
    - `subscriptions` - Assinaturas ativas dos clientes
    - `invoices` - Faturas e cobranças
    - `payments` - Histórico de pagamentos
    - `support_tickets` - Sistema de suporte
    - `domains` - Domínios gerenciados
    - `hosting_accounts` - Contas de hospedagem ativas
    - `vps_instances` - Instâncias VPS ativas

  2. Segurança
    - RLS habilitado em todas as tabelas
    - Políticas específicas para cada tipo de usuário
    - Autenticação via Supabase Auth

  3. Funcionalidades
    - Gestão completa de clientes e assinaturas
    - Sistema de cobrança automática
    - Controle de recursos e limites
    - Sistema de tickets de suporte
    - Relatórios e analytics
*/

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enum types
CREATE TYPE subscription_status AS ENUM ('active', 'suspended', 'cancelled', 'pending');
CREATE TYPE payment_status AS ENUM ('pending', 'completed', 'failed', 'refunded');
CREATE TYPE ticket_status AS ENUM ('open', 'in_progress', 'resolved', 'closed');
CREATE TYPE ticket_priority AS ENUM ('low', 'medium', 'high', 'urgent');
CREATE TYPE service_type AS ENUM ('hosting', 'vps', 'ecommerce', 'domain');

-- Tabela de clientes
CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  company_name text,
  contact_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text,
  document text, -- CPF/CNPJ
  address jsonb, -- {street, city, state, zip, country}
  billing_address jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  is_active boolean DEFAULT true,
  notes text
);

-- Planos de hospedagem
CREATE TABLE IF NOT EXISTS hosting_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price decimal(10,2) NOT NULL,
  billing_cycle text DEFAULT 'monthly', -- monthly, quarterly, yearly
  features jsonb NOT NULL, -- {storage_gb, bandwidth_gb, domains, emails, databases}
  limits jsonb, -- {cpu_limit, memory_limit, io_limit}
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Planos VPS
CREATE TABLE IF NOT EXISTS vps_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price decimal(10,2) NOT NULL,
  billing_cycle text DEFAULT 'monthly',
  specs jsonb NOT NULL, -- {cpu_cores, ram_gb, storage_gb, bandwidth_gb}
  features jsonb, -- {backup, monitoring, support_level}
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Planos de e-commerce
CREATE TABLE IF NOT EXISTS ecommerce_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price decimal(10,2) NOT NULL,
  billing_cycle text DEFAULT 'monthly',
  features jsonb NOT NULL, -- {products_limit, storage_gb, bandwidth_gb, payment_gateways}
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Assinaturas
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  service_type service_type NOT NULL,
  plan_id uuid NOT NULL, -- References hosting_plans, vps_plans, or ecommerce_plans
  status subscription_status DEFAULT 'pending',
  started_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  auto_renew boolean DEFAULT true,
  price decimal(10,2) NOT NULL,
  billing_cycle text NOT NULL,
  metadata jsonb, -- Service-specific data
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Contas de hospedagem
CREATE TABLE IF NOT EXISTS hosting_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subscription_id uuid REFERENCES subscriptions(id) ON DELETE CASCADE,
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  domain text,
  server_ip text,
  cpanel_url text,
  ftp_details jsonb, -- {host, port, username}
  database_details jsonb, -- {host, port, databases}
  email_accounts jsonb[], -- Array of email account details
  usage_stats jsonb, -- {storage_used, bandwidth_used, last_updated}
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Instâncias VPS
CREATE TABLE IF NOT EXISTS vps_instances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subscription_id uuid REFERENCES subscriptions(id) ON DELETE CASCADE,
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  hostname text NOT NULL,
  ip_address text UNIQUE NOT NULL,
  os text NOT NULL,
  root_password text, -- Encrypted
  ssh_port integer DEFAULT 22,
  control_panel_url text,
  specs jsonb NOT NULL, -- Current specs
  usage_stats jsonb, -- {cpu_usage, memory_usage, disk_usage, bandwidth_usage}
  backup_schedule jsonb, -- {frequency, retention, last_backup}
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Domínios
CREATE TABLE IF NOT EXISTS domains (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  domain_name text UNIQUE NOT NULL,
  registrar text,
  registered_at timestamptz,
  expires_at timestamptz,
  auto_renew boolean DEFAULT true,
  nameservers text[],
  dns_records jsonb, -- Array of DNS records
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Faturas
CREATE TABLE IF NOT EXISTS invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  subscription_id uuid REFERENCES subscriptions(id),
  invoice_number text UNIQUE NOT NULL,
  amount decimal(10,2) NOT NULL,
  tax_amount decimal(10,2) DEFAULT 0,
  total_amount decimal(10,2) NOT NULL,
  currency text DEFAULT 'BRL',
  due_date timestamptz NOT NULL,
  paid_at timestamptz,
  status payment_status DEFAULT 'pending',
  items jsonb NOT NULL, -- Array of invoice items
  payment_method text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Pagamentos
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  invoice_id uuid REFERENCES invoices(id),
  amount decimal(10,2) NOT NULL,
  currency text DEFAULT 'BRL',
  payment_method text NOT NULL,
  transaction_id text,
  gateway_response jsonb,
  status payment_status DEFAULT 'pending',
  processed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Tickets de suporte
CREATE TABLE IF NOT EXISTS support_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  subject text NOT NULL,
  description text NOT NULL,
  priority ticket_priority DEFAULT 'medium',
  status ticket_status DEFAULT 'open',
  category text,
  assigned_to uuid, -- Staff member
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  resolved_at timestamptz
);

-- Mensagens dos tickets
CREATE TABLE IF NOT EXISTS ticket_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid REFERENCES support_tickets(id) ON DELETE CASCADE,
  sender_id uuid REFERENCES auth.users(id),
  message text NOT NULL,
  is_internal boolean DEFAULT false,
  attachments jsonb, -- Array of file URLs
  created_at timestamptz DEFAULT now()
);

-- Logs de atividade
CREATE TABLE IF NOT EXISTS activity_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id),
  action text NOT NULL,
  resource_type text,
  resource_id uuid,
  details jsonb,
  ip_address text,
  user_agent text,
  created_at timestamptz DEFAULT now()
);

-- Configurações do sistema
CREATE TABLE IF NOT EXISTS system_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value jsonb NOT NULL,
  description text,
  updated_at timestamptz DEFAULT now()
);

-- Habilitar RLS em todas as tabelas
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE hosting_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE vps_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE ecommerce_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE hosting_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE vps_instances ENABLE ROW LEVEL SECURITY;
ALTER TABLE domains ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE support_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE ticket_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para customers
CREATE POLICY "Customers can view own data"
  ON customers
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Customers can update own data"
  ON customers
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

-- Políticas para planos (público para leitura)
CREATE POLICY "Anyone can view hosting plans"
  ON hosting_plans
  FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Anyone can view VPS plans"
  ON vps_plans
  FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

CREATE POLICY "Anyone can view ecommerce plans"
  ON ecommerce_plans
  FOR SELECT
  TO anon, authenticated
  USING (is_active = true);

-- Políticas para subscriptions
CREATE POLICY "Customers can view own subscriptions"
  ON subscriptions
  FOR SELECT
  TO authenticated
  USING (customer_id IN (SELECT id FROM customers WHERE user_id = auth.uid()));

-- Políticas para hosting_accounts
CREATE POLICY "Customers can view own hosting accounts"
  ON hosting_accounts
  FOR SELECT
  TO authenticated
  USING (customer_id IN (SELECT id FROM customers WHERE user_id = auth.uid()));

-- Políticas para vps_instances
CREATE POLICY "Customers can view own VPS instances"
  ON vps_instances
  FOR SELECT
  TO authenticated
  USING (customer_id IN (SELECT id FROM customers WHERE user_id = auth.uid()));

-- Políticas para domains
CREATE POLICY "Customers can view own domains"
  ON domains
  FOR SELECT
  TO authenticated
  USING (customer_id IN (SELECT id FROM customers WHERE user_id = auth.uid()));

-- Políticas para invoices
CREATE POLICY "Customers can view own invoices"
  ON invoices
  FOR SELECT
  TO authenticated
  USING (customer_id IN (SELECT id FROM customers WHERE user_id = auth.uid()));

-- Políticas para payments
CREATE POLICY "Customers can view own payments"
  ON payments
  FOR SELECT
  TO authenticated
  USING (customer_id IN (SELECT id FROM customers WHERE user_id = auth.uid()));

-- Políticas para support_tickets
CREATE POLICY "Customers can view own tickets"
  ON support_tickets
  FOR SELECT
  TO authenticated
  USING (customer_id IN (SELECT id FROM customers WHERE user_id = auth.uid()));

CREATE POLICY "Customers can create tickets"
  ON support_tickets
  FOR INSERT
  TO authenticated
  WITH CHECK (customer_id IN (SELECT id FROM customers WHERE user_id = auth.uid()));

-- Políticas para ticket_messages
CREATE POLICY "Users can view messages from own tickets"
  ON ticket_messages
  FOR SELECT
  TO authenticated
  USING (ticket_id IN (
    SELECT id FROM support_tickets 
    WHERE customer_id IN (SELECT id FROM customers WHERE user_id = auth.uid())
  ));

CREATE POLICY "Users can create messages in own tickets"
  ON ticket_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (
    sender_id = auth.uid() AND
    ticket_id IN (
      SELECT id FROM support_tickets 
      WHERE customer_id IN (SELECT id FROM customers WHERE user_id = auth.uid())
    )
  );

-- Políticas para activity_logs
CREATE POLICY "Customers can view own activity logs"
  ON activity_logs
  FOR SELECT
  TO authenticated
  USING (customer_id IN (SELECT id FROM customers WHERE user_id = auth.uid()));

-- Funções para triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers para updated_at
CREATE TRIGGER update_customers_updated_at BEFORE UPDATE ON customers FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_hosting_plans_updated_at BEFORE UPDATE ON hosting_plans FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_vps_plans_updated_at BEFORE UPDATE ON vps_plans FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_ecommerce_plans_updated_at BEFORE UPDATE ON ecommerce_plans FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_subscriptions_updated_at BEFORE UPDATE ON subscriptions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_hosting_accounts_updated_at BEFORE UPDATE ON hosting_accounts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_vps_instances_updated_at BEFORE UPDATE ON vps_instances FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_domains_updated_at BEFORE UPDATE ON domains FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_invoices_updated_at BEFORE UPDATE ON invoices FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_payments_updated_at BEFORE UPDATE ON payments FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_support_tickets_updated_at BEFORE UPDATE ON support_tickets FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_customers_user_id ON customers(user_id);
CREATE INDEX IF NOT EXISTS idx_customers_email ON customers(email);
CREATE INDEX IF NOT EXISTS idx_subscriptions_customer_id ON subscriptions(customer_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status);
CREATE INDEX IF NOT EXISTS idx_invoices_customer_id ON invoices(customer_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
CREATE INDEX IF NOT EXISTS idx_payments_customer_id ON payments(customer_id);
CREATE INDEX IF NOT EXISTS idx_support_tickets_customer_id ON support_tickets(customer_id);
CREATE INDEX IF NOT EXISTS idx_support_tickets_status ON support_tickets(status);
CREATE INDEX IF NOT EXISTS idx_activity_logs_customer_id ON activity_logs(customer_id);