# 🚀 Guia de Instalação - Sistema de Hospedagem
## Ubuntu 24.04 LTS - Passo a Passo Completo

Este guia irá te ajudar a instalar e configurar o sistema de hospedagem em um VPS Ubuntu 24.04 LTS.

---

## 📋 Pré-requisitos

- VPS com Ubuntu 24.04 LTS
- Acesso root ou usuário com sudo
- Mínimo 2GB RAM, 2 vCPU, 20GB SSD
- Domínio apontado para o IP do servidor
- Conta no Supabase (gratuita)

---

## 🔧 1. Preparação do Servidor

### 1.1 Atualizar o Sistema
```bash
# Conectar ao servidor via SSH
ssh root@SEU_IP_DO_SERVIDOR

# Atualizar pacotes
sudo apt update && sudo apt upgrade -y

# Instalar pacotes essenciais
sudo apt install -y curl wget git unzip software-properties-common apt-transport-https ca-certificates gnupg lsb-release
```

### 1.2 Configurar Firewall
```bash
# Habilitar UFW
sudo ufw enable

# Permitir SSH, HTTP e HTTPS
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Verificar status
sudo ufw status
```

### 1.3 Criar Usuário para Aplicação
```bash
# Criar usuário
sudo adduser hostpro

# Adicionar ao grupo sudo
sudo usermod -aG sudo hostpro

# Trocar para o usuário
su - hostpro
```

---

## 🟢 2. Instalação do Node.js

### 2.1 Instalar Node.js 20 LTS
```bash
# Adicionar repositório NodeSource
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -

# Instalar Node.js
sudo apt install -y nodejs

# Verificar versões
node --version  # deve mostrar v20.x.x
npm --version   # deve mostrar 10.x.x
```

### 2.2 Instalar PM2 (Gerenciador de Processos)
```bash
# Instalar PM2 globalmente
sudo npm install -g pm2

# Configurar PM2 para iniciar com o sistema
pm2 startup
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u hostpro --hp /home/hostpro
```

---

## 🌐 3. Instalação do Nginx

### 3.1 Instalar Nginx
```bash
# Instalar Nginx
sudo apt install -y nginx

# Iniciar e habilitar Nginx
sudo systemctl start nginx
sudo systemctl enable nginx

# Verificar status
sudo systemctl status nginx
```

### 3.2 Configurar Nginx para a Aplicação
```bash
# Criar arquivo de configuração
sudo nano /etc/nginx/sites-available/hostpro

# Adicionar a configuração (substitua SEU_DOMINIO.com):
```

```nginx
server {
    listen 80;
    server_name SEU_DOMINIO.com www.SEU_DOMINIO.com;

    # Redirecionar para HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name SEU_DOMINIO.com www.SEU_DOMINIO.com;

    # Certificados SSL (serão configurados depois)
    ssl_certificate /etc/letsencrypt/live/SEU_DOMINIO.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/SEU_DOMINIO.com/privkey.pem;

    # Configurações SSL
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;

    # Localização da aplicação
    root /home/hostpro/hostpro-app/dist;
    index index.html;

    # Configurações de cache
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Fallback para SPA
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Logs
    access_log /var/log/nginx/hostpro_access.log;
    error_log /var/log/nginx/hostpro_error.log;
}
```

```bash
# Habilitar o site
sudo ln -s /etc/nginx/sites-available/hostpro /etc/nginx/sites-enabled/

# Remover configuração padrão
sudo rm /etc/nginx/sites-enabled/default

# Testar configuração
sudo nginx -t

# Recarregar Nginx
sudo systemctl reload nginx
```

---

## 🔒 4. Configuração SSL com Let's Encrypt

### 4.1 Instalar Certbot
```bash
# Instalar Certbot
sudo apt install -y certbot python3-certbot-nginx

# Obter certificado SSL (substitua SEU_DOMINIO.com)
sudo certbot --nginx -d SEU_DOMINIO.com -d www.SEU_DOMINIO.com

# Configurar renovação automática
sudo crontab -e

# Adicionar linha para renovação automática:
0 12 * * * /usr/bin/certbot renew --quiet
```

---

## 📦 5. Deploy da Aplicação

### 5.1 Clonar e Configurar o Projeto
```bash
# Ir para o diretório home
cd /home/hostpro

# Clonar o repositório (ou fazer upload dos arquivos)
git clone https://github.com/SEU_USUARIO/hostpro-app.git
# OU fazer upload via SCP/SFTP

cd hostpro-app

# Instalar dependências
npm install

# Criar arquivo de ambiente
nano .env
```

### 5.2 Configurar Variáveis de Ambiente
```bash
# Conteúdo do arquivo .env
VITE_SUPABASE_URL=https://SEU_PROJETO.supabase.co
VITE_SUPABASE_ANON_KEY=SUA_CHAVE_ANONIMA_SUPABASE

# Configurações de produção
NODE_ENV=production
PORT=3000
```

### 5.3 Build da Aplicação
```bash
# Fazer build da aplicação
npm run build

# Verificar se o build foi criado
ls -la dist/
```

---

## 🗄️ 6. Configuração do Supabase

### 6.1 Criar Projeto no Supabase
1. Acesse [supabase.com](https://supabase.com)
2. Crie uma conta gratuita
3. Crie um novo projeto
4. Anote a URL e a chave anônima

### 6.2 Configurar Banco de Dados
```bash
# Instalar Supabase CLI (opcional, para migrações)
npm install -g supabase

# Fazer login no Supabase
supabase login

# Aplicar migrações (se usando CLI)
supabase db push
```

### 6.3 Configurar Autenticação
No painel do Supabase:
1. Vá em Authentication > Settings
2. Configure Site URL: `https://SEU_DOMINIO.com`
3. Configure Redirect URLs: `https://SEU_DOMINIO.com/**`
4. Desabilite "Confirm email" se necessário

---

## 🚀 7. Inicialização da Aplicação

### 7.1 Configurar PM2
```bash
# Criar arquivo de configuração do PM2
nano ecosystem.config.js
```

```javascript
module.exports = {
  apps: [{
    name: 'hostpro-app',
    script: 'npm',
    args: 'run preview',
    cwd: '/home/hostpro/hostpro-app',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    error_file: '/home/hostpro/logs/err.log',
    out_file: '/home/hostpro/logs/out.log',
    log_file: '/home/hostpro/logs/combined.log',
    time: true
  }]
};
```

```bash
# Criar diretório de logs
mkdir -p /home/hostpro/logs

# Iniciar aplicação com PM2
pm2 start ecosystem.config.js

# Salvar configuração do PM2
pm2 save

# Verificar status
pm2 status
pm2 logs
```

---

## 🔧 8. Configurações Adicionais

### 8.1 Configurar Logrotate
```bash
# Criar configuração de rotação de logs
sudo nano /etc/logrotate.d/hostpro
```

```bash
/home/hostpro/logs/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 hostpro hostpro
    postrotate
        pm2 reloadLogs
    endscript
}
```

### 8.2 Configurar Monitoramento
```bash
# Instalar htop para monitoramento
sudo apt install -y htop

# Configurar monitoramento do PM2
pm2 install pm2-logrotate
pm2 set pm2-logrotate:max_size 10M
pm2 set pm2-logrotate:retain 30
```

---

## 🧪 9. Testes e Verificação

### 9.1 Testar a Aplicação
```bash
# Verificar se o Nginx está funcionando
curl -I http://SEU_DOMINIO.com

# Verificar SSL
curl -I https://SEU_DOMINIO.com

# Verificar logs
pm2 logs hostpro-app
sudo tail -f /var/log/nginx/hostpro_access.log
```

### 9.2 Testes de Performance
```bash
# Instalar ferramentas de teste
sudo apt install -y apache2-utils

# Teste de carga básico
ab -n 100 -c 10 https://SEU_DOMINIO.com/
```

---

## 🔄 10. Backup e Manutenção

### 10.1 Script de Backup
```bash
# Criar script de backup
nano /home/hostpro/backup.sh
```

```bash
#!/bin/bash
BACKUP_DIR="/home/hostpro/backups"
DATE=$(date +%Y%m%d_%H%M%S)

# Criar diretório de backup
mkdir -p $BACKUP_DIR

# Backup da aplicação
tar -czf $BACKUP_DIR/app_$DATE.tar.gz /home/hostpro/hostpro-app

# Backup dos logs
tar -czf $BACKUP_DIR/logs_$DATE.tar.gz /home/hostpro/logs

# Remover backups antigos (manter apenas 7 dias)
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete

echo "Backup concluído: $DATE"
```

```bash
# Tornar executável
chmod +x /home/hostpro/backup.sh

# Configurar backup automático
crontab -e

# Adicionar linha para backup diário às 2h da manhã:
0 2 * * * /home/hostpro/backup.sh
```

### 10.2 Script de Atualização
```bash
# Criar script de atualização
nano /home/hostpro/update.sh
```

```bash
#!/bin/bash
cd /home/hostpro/hostpro-app

echo "Fazendo backup antes da atualização..."
./backup.sh

echo "Parando aplicação..."
pm2 stop hostpro-app

echo "Atualizando código..."
git pull origin main

echo "Instalando dependências..."
npm install

echo "Fazendo build..."
npm run build

echo "Reiniciando aplicação..."
pm2 restart hostpro-app

echo "Atualização concluída!"
pm2 status
```

```bash
# Tornar executável
chmod +x /home/hostpro/update.sh
```

---

## 🚨 11. Solução de Problemas

### 11.1 Problemas Comuns

**Erro 502 Bad Gateway:**
```bash
# Verificar se a aplicação está rodando
pm2 status

# Verificar logs
pm2 logs hostpro-app
sudo tail -f /var/log/nginx/hostpro_error.log
```

**Erro de SSL:**
```bash
# Renovar certificado
sudo certbot renew

# Verificar configuração SSL
sudo nginx -t
```

**Alto uso de memória:**
```bash
# Verificar uso de recursos
htop
pm2 monit

# Reiniciar aplicação se necessário
pm2 restart hostpro-app
```

### 11.2 Comandos Úteis
```bash
# Status dos serviços
sudo systemctl status nginx
pm2 status

# Logs em tempo real
pm2 logs --lines 100
sudo tail -f /var/log/nginx/hostpro_access.log

# Reiniciar serviços
sudo systemctl restart nginx
pm2 restart hostpro-app

# Verificar portas em uso
sudo netstat -tlnp | grep :80
sudo netstat -tlnp | grep :443
```

---

## ✅ 12. Checklist Final

- [ ] Ubuntu 24.04 atualizado
- [ ] Node.js 20 LTS instalado
- [ ] PM2 configurado e funcionando
- [ ] Nginx instalado e configurado
- [ ] SSL configurado com Let's Encrypt
- [ ] Aplicação fazendo build corretamente
- [ ] Supabase configurado
- [ ] Domínio apontando para o servidor
- [ ] Firewall configurado
- [ ] Logs funcionando
- [ ] Backup automático configurado
- [ ] Monitoramento ativo

---

## 📞 Suporte

Se encontrar problemas durante a instalação:

1. Verifique os logs: `pm2 logs` e `/var/log/nginx/`
2. Teste a conectividade: `curl -I https://SEU_DOMINIO.com`
3. Verifique as configurações do Supabase
4. Confirme se o domínio está apontando corretamente

---

## 🎉 Parabéns!

Seu sistema de hospedagem está agora funcionando em produção! 

Acesse `https://SEU_DOMINIO.com` para ver sua aplicação rodando.

**Próximos passos:**
- Configure o painel administrativo
- Adicione os primeiros planos de hospedagem
- Configure os métodos de pagamento
- Teste o sistema de suporte

---

*Guia criado para Ubuntu 24.04 LTS - Versão 1.0*