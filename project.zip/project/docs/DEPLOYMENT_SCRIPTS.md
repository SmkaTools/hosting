# 🛠️ Scripts de Deployment
## Automação para Ubuntu 24.04

Scripts prontos para automatizar a instalação e manutenção do sistema.

---

## 📦 1. Script de Instalação Completa

### install.sh
```bash
#!/bin/bash

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para log
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

error() {
    echo -e "${RED}[ERROR] $1${NC}"
}

warning() {
    echo -e "${YELLOW}[WARNING] $1${NC}"
}

info() {
    echo -e "${BLUE}[INFO] $1${NC}"
}

# Verificar se está rodando como root
if [[ $EUID -eq 0 ]]; then
   error "Este script não deve ser executado como root"
   exit 1
fi

log "🚀 Iniciando instalação do Sistema de Hospedagem"

# Variáveis
DOMAIN=""
SUPABASE_URL=""
SUPABASE_ANON_KEY=""
APP_DIR="/home/$(whoami)/hostpro-app"

# Solicitar informações do usuário
read -p "Digite seu domínio (ex: exemplo.com): " DOMAIN
read -p "Digite a URL do Supabase: " SUPABASE_URL
read -p "Digite a chave anônima do Supabase: " SUPABASE_ANON_KEY

if [[ -z "$DOMAIN" || -z "$SUPABASE_URL" || -z "$SUPABASE_ANON_KEY" ]]; then
    error "Todas as informações são obrigatórias!"
    exit 1
fi

log "Atualizando sistema..."
sudo apt update && sudo apt upgrade -y

log "Instalando dependências..."
sudo apt install -y curl wget git unzip software-properties-common apt-transport-https ca-certificates gnupg lsb-release nginx certbot python3-certbot-nginx htop apache2-utils

log "Configurando firewall..."
sudo ufw --force enable
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

log "Instalando Node.js 20 LTS..."
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

log "Instalando PM2..."
sudo npm install -g pm2 supabase

log "Configurando PM2 para inicialização automática..."
pm2 startup | grep -E '^sudo' | bash

log "Criando diretórios..."
mkdir -p ~/logs ~/backups

log "Configurando Nginx..."
sudo tee /etc/nginx/sites-available/hostpro > /dev/null <<EOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;
    return 301 https://\$server_name\$request_uri;
}

server {
    listen 443 ssl http2;
    server_name $DOMAIN www.$DOMAIN;

    ssl_certificate /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;

    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;

    root $APP_DIR/dist;
    index index.html;

    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    location / {
        try_files \$uri \$uri/ /index.html;
    }

    access_log /var/log/nginx/hostpro_access.log;
    error_log /var/log/nginx/hostpro_error.log;
}
EOF

sudo ln -sf /etc/nginx/sites-available/hostpro /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

log "Obtendo certificado SSL..."
sudo certbot --nginx -d $DOMAIN -d www.$DOMAIN --non-interactive --agree-tos --email admin@$DOMAIN

log "Configurando renovação automática do SSL..."
(sudo crontab -l 2>/dev/null; echo "0 12 * * * /usr/bin/certbot renew --quiet") | sudo crontab -

log "Clonando aplicação..."
if [ -d "$APP_DIR" ]; then
    rm -rf "$APP_DIR"
fi

# Aqui você deve clonar seu repositório ou fazer upload dos arquivos
# git clone https://github.com/SEU_USUARIO/hostpro-app.git $APP_DIR
# Por enquanto, vamos criar a estrutura básica
mkdir -p $APP_DIR

log "Configurando variáveis de ambiente..."
cat > $APP_DIR/.env <<EOF
VITE_SUPABASE_URL=$SUPABASE_URL
VITE_SUPABASE_ANON_KEY=$SUPABASE_ANON_KEY
NODE_ENV=production
PORT=3000
EOF

log "Criando configuração do PM2..."
cat > $APP_DIR/ecosystem.config.js <<EOF
module.exports = {
  apps: [{
    name: 'hostpro-app',
    script: 'npm',
    args: 'run preview',
    cwd: '$APP_DIR',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    error_file: '~/logs/err.log',
    out_file: '~/logs/out.log',
    log_file: '~/logs/combined.log',
    time: true
  }]
};
EOF

log "Criando scripts de manutenção..."

# Script de backup
cat > ~/backup.sh <<'EOF'
#!/bin/bash
BACKUP_DIR="$HOME/backups"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

tar -czf $BACKUP_DIR/app_$DATE.tar.gz $HOME/hostpro-app
tar -czf $BACKUP_DIR/logs_$DATE.tar.gz $HOME/logs

find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete

echo "Backup concluído: $DATE"
EOF

# Script de atualização
cat > ~/update.sh <<'EOF'
#!/bin/bash
cd $HOME/hostpro-app

echo "Fazendo backup..."
$HOME/backup.sh

echo "Parando aplicação..."
pm2 stop hostpro-app

echo "Atualizando código..."
git pull origin main

echo "Instalando dependências..."
npm install

echo "Fazendo build..."
npm run build

echo "Reiniciando aplicação..."
pm2 restart hostpro-app

echo "Atualização concluída!"
pm2 status
EOF

chmod +x ~/backup.sh ~/update.sh

log "Configurando backup automático..."
(crontab -l 2>/dev/null; echo "0 2 * * * $HOME/backup.sh") | crontab -

log "Configurando logrotate..."
sudo tee /etc/logrotate.d/hostpro > /dev/null <<EOF
$HOME/logs/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 $(whoami) $(whoami)
    postrotate
        pm2 reloadLogs
    endscript
}
EOF

log "Configurando monitoramento do PM2..."
pm2 install pm2-logrotate
pm2 set pm2-logrotate:max_size 10M
pm2 set pm2-logrotate:retain 30

log "✅ Instalação base concluída!"
info "Próximos passos:"
info "1. Faça upload dos arquivos da aplicação para: $APP_DIR"
info "2. Execute: cd $APP_DIR && npm install && npm run build"
info "3. Execute: pm2 start ecosystem.config.js"
info "4. Execute: pm2 save"
info "5. Acesse: https://$DOMAIN"

log "🎉 Sistema pronto para uso!"
```

---

## 🔄 2. Script de Deploy Automático

### deploy.sh
```bash
#!/bin/bash

# Cores
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

error() {
    echo -e "${RED}[ERROR] $1${NC}"
}

warning() {
    echo -e "${YELLOW}[WARNING] $1${NC}"
}

APP_DIR="$HOME/hostpro-app"
BACKUP_DIR="$HOME/backups"

log "🚀 Iniciando deploy da aplicação..."

# Verificar se o diretório existe
if [ ! -d "$APP_DIR" ]; then
    error "Diretório da aplicação não encontrado: $APP_DIR"
    exit 1
fi

cd $APP_DIR

log "Fazendo backup da versão atual..."
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR
tar -czf $BACKUP_DIR/pre_deploy_$DATE.tar.gz .

log "Parando aplicação..."
pm2 stop hostpro-app 2>/dev/null || true

log "Atualizando código..."
if [ -d ".git" ]; then
    git pull origin main
else
    warning "Não é um repositório Git. Pulando atualização de código."
fi

log "Instalando/atualizando dependências..."
npm install

log "Executando build..."
npm run build

if [ $? -ne 0 ]; then
    error "Falha no build! Restaurando backup..."
    pm2 start ecosystem.config.js
    exit 1
fi

log "Iniciando aplicação..."
pm2 start ecosystem.config.js

log "Salvando configuração do PM2..."
pm2 save

log "Verificando status..."
sleep 5
pm2 status

log "Testando aplicação..."
if curl -f -s http://localhost:3000 > /dev/null; then
    log "✅ Deploy concluído com sucesso!"
else
    error "❌ Aplicação não está respondendo!"
    exit 1
fi

log "🎉 Deploy finalizado!"
```

---

## 🔧 3. Script de Monitoramento

### monitor.sh
```bash
#!/bin/bash

# Cores
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

error() {
    echo -e "${RED}[ERROR] $1${NC}"
}

warning() {
    echo -e "${YELLOW}[WARNING] $1${NC}"
}

info() {
    echo -e "${BLUE}[INFO] $1${NC}"
}

# Função para verificar serviços
check_service() {
    local service=$1
    if systemctl is-active --quiet $service; then
        log "✅ $service está rodando"
        return 0
    else
        error "❌ $service não está rodando"
        return 1
    fi
}

# Função para verificar aplicação PM2
check_pm2_app() {
    local app=$1
    local status=$(pm2 jlist | jq -r ".[] | select(.name==\"$app\") | .pm2_env.status")
    
    if [ "$status" = "online" ]; then
        log "✅ $app está online"
        return 0
    else
        error "❌ $app está $status"
        return 1
    fi
}

# Função para verificar uso de recursos
check_resources() {
    local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}')
    local mem_usage=$(free | grep Mem | awk '{printf("%.1f", $3/$2 * 100.0)}')
    local disk_usage=$(df -h / | awk 'NR==2{printf "%s", $5}' | sed 's/%//')
    
    info "💻 Uso de CPU: ${cpu_usage}%"
    info "🧠 Uso de Memória: ${mem_usage}%"
    info "💾 Uso de Disco: ${disk_usage}%"
    
    # Alertas
    if (( $(echo "$cpu_usage > 80" | bc -l) )); then
        warning "Alto uso de CPU: ${cpu_usage}%"
    fi
    
    if (( $(echo "$mem_usage > 80" | bc -l) )); then
        warning "Alto uso de memória: ${mem_usage}%"
    fi
    
    if [ "$disk_usage" -gt 80 ]; then
        warning "Alto uso de disco: ${disk_usage}%"
    fi
}

# Função para verificar conectividade
check_connectivity() {
    local domain=$1
    
    if curl -f -s -o /dev/null "https://$domain"; then
        log "✅ Site acessível: https://$domain"
    else
        error "❌ Site não acessível: https://$domain"
    fi
    
    # Verificar certificado SSL
    local ssl_expiry=$(echo | openssl s_client -servername $domain -connect $domain:443 2>/dev/null | openssl x509 -noout -dates | grep notAfter | cut -d= -f2)
    local ssl_expiry_epoch=$(date -d "$ssl_expiry" +%s)
    local current_epoch=$(date +%s)
    local days_until_expiry=$(( (ssl_expiry_epoch - current_epoch) / 86400 ))
    
    if [ $days_until_expiry -lt 30 ]; then
        warning "⚠️ Certificado SSL expira em $days_until_expiry dias"
    else
        info "🔒 Certificado SSL válido por $days_until_expiry dias"
    fi
}

log "🔍 Iniciando monitoramento do sistema..."

# Verificar serviços
check_service "nginx"
check_service "ufw"

# Verificar aplicação PM2
check_pm2_app "hostpro-app"

# Verificar recursos
check_resources

# Verificar conectividade (substitua pelo seu domínio)
# check_connectivity "seudominio.com"

# Verificar logs recentes
log "📋 Últimas entradas de log:"
pm2 logs hostpro-app --lines 5 --nostream

log "🏁 Monitoramento concluído"
```

---

## 🛡️ 4. Script de Segurança

### security.sh
```bash
#!/bin/bash

# Cores
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

error() {
    echo -e "${RED}[ERROR] $1${NC}"
}

warning() {
    echo -e "${YELLOW}[WARNING] $1${NC}"
}

log "🛡️ Executando verificações de segurança..."

# Atualizar sistema
log "Verificando atualizações do sistema..."
sudo apt update
UPDATES=$(apt list --upgradable 2>/dev/null | wc -l)
if [ $UPDATES -gt 1 ]; then
    warning "$((UPDATES-1)) atualizações disponíveis"
    read -p "Deseja instalar as atualizações? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        sudo apt upgrade -y
    fi
fi

# Verificar firewall
log "Verificando configuração do firewall..."
if sudo ufw status | grep -q "Status: active"; then
    log "✅ Firewall ativo"
    sudo ufw status numbered
else
    error "❌ Firewall inativo"
fi

# Verificar tentativas de login SSH
log "Verificando tentativas de login SSH..."
FAILED_LOGINS=$(grep "Failed password" /var/log/auth.log | wc -l)
if [ $FAILED_LOGINS -gt 10 ]; then
    warning "⚠️ $FAILED_LOGINS tentativas de login falharam"
    echo "Últimas tentativas:"
    grep "Failed password" /var/log/auth.log | tail -5
fi

# Verificar processos suspeitos
log "Verificando processos com alto uso de CPU..."
ps aux --sort=-%cpu | head -10

# Verificar conexões de rede
log "Verificando conexões de rede ativas..."
netstat -tuln | grep LISTEN

# Verificar integridade dos arquivos críticos
log "Verificando permissões de arquivos críticos..."
ls -la /etc/nginx/sites-enabled/
ls -la ~/.ssh/ 2>/dev/null || echo "Diretório .ssh não encontrado"

# Verificar logs de erro do Nginx
log "Verificando logs de erro do Nginx..."
ERROR_COUNT=$(sudo tail -100 /var/log/nginx/error.log | wc -l)
if [ $ERROR_COUNT -gt 0 ]; then
    warning "⚠️ $ERROR_COUNT erros encontrados no Nginx"
    echo "Últimos erros:"
    sudo tail -5 /var/log/nginx/error.log
fi

log "🏁 Verificação de segurança concluída"
```

---

## 📊 5. Script de Relatórios

### report.sh
```bash
#!/bin/bash

# Cores
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

info() {
    echo -e "${BLUE}[INFO] $1${NC}"
}

REPORT_FILE="$HOME/reports/system_report_$(date +%Y%m%d_%H%M%S).txt"
mkdir -p "$HOME/reports"

log "📊 Gerando relatório do sistema..."

{
    echo "========================================="
    echo "RELATÓRIO DO SISTEMA - $(date)"
    echo "========================================="
    echo
    
    echo "INFORMAÇÕES DO SISTEMA:"
    echo "----------------------"
    uname -a
    echo "Uptime: $(uptime)"
    echo
    
    echo "USO DE RECURSOS:"
    echo "---------------"
    echo "CPU:"
    top -bn1 | grep "Cpu(s)"
    echo
    echo "Memória:"
    free -h
    echo
    echo "Disco:"
    df -h
    echo
    
    echo "SERVIÇOS:"
    echo "--------"
    systemctl status nginx --no-pager -l
    echo
    pm2 status
    echo
    
    echo "LOGS RECENTES:"
    echo "-------------"
    echo "Nginx Access (últimas 10 linhas):"
    sudo tail -10 /var/log/nginx/hostpro_access.log 2>/dev/null || echo "Log não encontrado"
    echo
    echo "PM2 Logs (últimas 10 linhas):"
    pm2 logs hostpro-app --lines 10 --nostream 2>/dev/null || echo "App não encontrado"
    echo
    
    echo "CONECTIVIDADE:"
    echo "-------------"
    echo "Portas abertas:"
    netstat -tuln | grep LISTEN
    echo
    
    echo "SEGURANÇA:"
    echo "---------"
    echo "Status do Firewall:"
    sudo ufw status
    echo
    echo "Últimas tentativas de login SSH:"
    grep "Accepted\|Failed" /var/log/auth.log | tail -5
    echo
    
    echo "========================================="
    echo "Relatório gerado em: $(date)"
    echo "========================================="
    
} > "$REPORT_FILE"

log "✅ Relatório salvo em: $REPORT_FILE"

# Mostrar resumo na tela
info "📋 RESUMO DO SISTEMA:"
echo "CPU: $(top -bn1 | grep "Cpu(s)" | awk '{print $2}')"
echo "Memória: $(free | grep Mem | awk '{printf("%.1f%% usado", $3/$2 * 100.0)}')"
echo "Disco: $(df -h / | awk 'NR==2{printf "%s usado", $5}')"
echo "Nginx: $(systemctl is-active nginx)"
echo "App: $(pm2 jlist | jq -r '.[] | select(.name=="hostpro-app") | .pm2_env.status' 2>/dev/null || echo 'não encontrado')"
```

---

## 🚀 6. Como Usar os Scripts

### Instalação dos Scripts
```bash
# Baixar todos os scripts
mkdir -p ~/scripts
cd ~/scripts

# Tornar executáveis
chmod +x *.sh

# Criar aliases para facilitar o uso
echo "alias hostpro-deploy='~/scripts/deploy.sh'" >> ~/.bashrc
echo "alias hostpro-monitor='~/scripts/monitor.sh'" >> ~/.bashrc
echo "alias hostpro-security='~/scripts/security.sh'" >> ~/.bashrc
echo "alias hostpro-report='~/scripts/report.sh'" >> ~/.bashrc

# Recarregar bashrc
source ~/.bashrc
```

### Uso Diário
```bash
# Deploy da aplicação
hostpro-deploy

# Monitoramento
hostpro-monitor

# Verificação de segurança
hostpro-security

# Gerar relatório
hostpro-report
```

### Automação com Cron
```bash
# Editar crontab
crontab -e

# Adicionar tarefas automáticas:
# Monitoramento a cada 30 minutos
*/30 * * * * ~/scripts/monitor.sh >> ~/logs/monitor.log 2>&1

# Verificação de segurança diária às 6h
0 6 * * * ~/scripts/security.sh >> ~/logs/security.log 2>&1

# Relatório semanal aos domingos às 8h
0 8 * * 0 ~/scripts/report.sh >> ~/logs/reports.log 2>&1
```

---

*Scripts de deployment para Ubuntu 24.04 LTS - Versão 1.0*